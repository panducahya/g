# -*- coding: utf-8 -*- 
from thrift.transport import TTransport,TSocket,THttpClient,TTransport,TZlibTransport
from thrift.protocol import TCompactProtocol,TMultiplexedProtocol,TProtocol
from thrift.server import THttpServer,TServer,TProcessPoolServer
from thrift import transport, protocol, server, ext, ecc
from thrift.ecc import rec
from thrift.unverting import *
from thrift.TMultiplexedProcessor import *
from thrift.TSerialization import *
from thrift.TRecursive import *
from thrift.Thrift import *
import ais
from ais import *
from akad.ttypes import *
from datetime import datetime
from time import sleep
from random import randint
from bs4 import BeautifulSoup
from googletrans import Translator
from multiprocessing import Pool, Process
from subprocess import check_output
from humanfriendly import format_timespan, format_size, format_number, format_length
import html5lib
import requests,json,urllib3
import youtube_dl
import pyimgflip
import pytz, pafy, livejson, time, asyncio, random, multiprocessing, timeit, sys, json, ctypes, codecs, tweepy, threading, glob, re, ast, six, os, subprocess, wikipedia, atexit, goslate, urllib, urllib.parse, urllib3, string, tempfile, traceback, shutil, unicodedata

#===============================#
ais = LINE('u8842f214a70223cf01542b4347734e98:aWF0OiAxNjE5MDk1MjQ3Nzc3Cg==..XvvtNsXm3Guqlnr0iSWGRNeH3ks=',appName="ANDROIDLITE\t2.16.0\tAndroid OS\t5.1.1")
print ("===============[1 LOGIN]===============\n")

a1 = LINE('u7f50f81a6286bb396d79bb6bd02503cd:aWF0OiAxNjE5MTAyOTQ4MTE2Cg==..DlFTsORmKehkRpZ0pG7nE84MmDk=',appName="ANDROIDLITE\t2.16.0\tAndroid OS\t5.1.1")
print ("===============[2 LOGIN]===============\n")

a2 = LINE('u4c0a5a23bd6928b4c113c5024c24d3f9:aWF0OiAxNjE5MTAzMDkyNTM1Cg==..uT8+lXaxCceMA1mIJ8Ora+Kcnrs=',appName="ANDROIDLITE\t2.16.0\tAndroid OS\t5.1.1")
print ("===============[3 LOGIN]===============\n")

a3 = LINE('u6734a03ec6137e96a756de85c80e927d:aWF0OiAxNjE5MTAzMDUyNTA1Cg==..fBmiTsp8dEhTlEcqc5S6XWnR9aE=',appName="ANDROIDLITE\t2.16.0\tAndroid OS\t5.1.1")
print ("===============[3 LOGIN]===============\n")

a4 = LINE('u23036cfa21a0b27e6f71c49e0682251a:aWF0OiAxNjE5MTAyOTg5MjE1Cg==..gD/XFECv9GNJ27wgyPZeGsyDFcg=',appName="ANDROIDLITE\t2.16.0\tAndroid OS\t5.1.1")
print ("===============[4 LOGIN]===============\n")

a5 = LINE('u080145fd54c6b2a02bc9d35f2188058e:aWF0OiAxNjE2OTE0MTA5OTE2Cg==..UyLCkfW5FhFiwojpAXvVeJOs6Gk=',appName="ANDROIDLITE\t2.16.0\tAndroid OS\t5.1.1")
print ("===============[5 LOGIN]===============\n")

ajs = LINE('u45ba6e3dba1262b442856ec305321707:aWF0OiAxNjE5MTAyOTgzMjE1Cg==..cAF5aQ5K7tjBcQ4yZqg3BXI3k0A=',appName="ANDROIDLITE\t2.16.0\tAndroid OS\t5.1.1")
print ("===============[ajs LOGIN]===============\n")

oepoll = OEPoll(ais)
call = (ais)
creator = ["u1e812bcfc29ed4d9eae95a64a59b9568" ,"ud38034bb40a0959d00285c6748afcde3"]
owner = ["u1e812bcfc29ed4d9eae95a64a59b9568" ,"ud38034bb40a0959d00285c6748afcde3"]
admin = ["u1e812bcfc29ed4d9eae95a64a59b9568" ,"ud38034bb40a0959d00285c6748afcde3"]
staff = ["u1e812bcfc29ed4d9eae95a64a59b9568" ,"ud38034bb40a0959d00285c6748afcde3"]
mid = ais.getProfile().mid
Amid = a1.getProfile().mid
Bmid = a2.getProfile().mid
Cmid = a3.getProfile().mid
Dmid = a4.getProfile().mid
Emid = a5.getProfile().mid
Xmid = ajs.getProfile().mid
KAC = [ais,a1,a2,a3,a4,a5,ajs]
ABC = [a1,a2,a3,a4,a5]
AJS = [ajs]
Bots = [mid,Amid,Bmid,Cmid,Dmid,Emid,Xmid]
Saints = admin + staff + Bots

responsename1 = a1.getProfile().displayName
responsename2 = a2.getProfile().displayName
responsename3 = a3.getProfile().displayName
responsename4 = a4.getProfile().displayName
responsename5 = a5.getProfile().displayName
responsename6 = ajs.getProfile().displayName

settings = {
    "Picture":False,
    "group":{},
    "groupPicture":False,
    "changePicture":False,
    "autoJoinTicket":False,
    "userAgent": [
        "Mozilla/5.0 (Linux; Android 5.1.1; ASUS_X014D Build/LMY47V; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/79.0.3945.93 Mobile Safari/537.36 Line/9.22.2"
        "Mozilla/5.0 (X11; U; Linux i586; de; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (X11; U; Linux amd64; rv:5.0) Gecko/20100101 Firefox/5.0 (Debian)",
        "Mozilla/5.0 (X11; U; Linux amd64; en-US; rv:5.0) Gecko/20110619 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux) Gecko Firefox/5.0",
        "Mozilla/5.0 (X11; Linux x86_64; rv:5.0) Gecko/20100101 Firefox/5.0 FirePHP/0.5",
        "Mozilla/5.0 (X11; Linux x86_64; rv:5.0) Gecko/20100101 Firefox/5.0 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux x86_64) Gecko Firefox/5.0",
        "Mozilla/5.0 (X11; Linux ppc; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux AMD64) Gecko Firefox/5.0",
        "Mozilla/5.0 (X11; FreeBSD amd64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.2; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:5.0) Gecko/20110619 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1; rv:6.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1.1; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.2; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.1; U; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.1; rv:2.0.1) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.0; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.0; rv:5.0) Gecko/20100101 Firefox/5.0"
    ]
}

wait = {
   "backupx": False,
    "cancel": True,
    "cjs": True,
    "vit": True,
    "js": True,
    "gs": True,
    "qr": True,
    "kick": False,
    "joinan": False,
    "Mentiongift": False,
    "Mentionkick": False,
    "Respontag": "tag mulu dah langsung pc aja",
    "autoBlock": False,
    "Talkblacklist": {},
    "Talkdblacklist": False,
    "Talkwblacklist": False,
    "addadmin": False,
    "addbots": False,
    "addstaff": False,
    "admin": {},
    "autoAdd": False,
    "autoJoin": True,
    "autoJoinTicket": False,
    "autoLeave": False,
    "autoLeave1": False,
    "blacklist": {},
    "bots": {},
    "comment": "udah pan like ya om",
    "contact": False,
    "dblacklist": False,
    "delladmin": False,
    "dellbots": False,
    "dellstaff": False,
    "detectMention": False,
    "leave": "fyuhh",
    "limit": 1,
    "mention": "pandu lagi sibuk langsung pc aja",
    "message": "Thanks For Add Me",
    "owner": {},
    "selfbot": True,
    "staff": {},
    "sticker": False,
    "talkban": False,
    "unsend": False,
    "wblacklist": False,
    "welcome": "welcome bby<3",
    "welcomeOn": False
    }

myProfile = {
	"displayName": "",
	"statusMessage": "",
	"pictureStatus": ""
}
protectqr = []
protectkick = []
protectjoin = []
protectinvite = []
protectcancel = []
welcome = []
scProfile = ais.getProfile()
myProfile["displayName"] = scProfile.displayName
myProfile["statusMessage"] = scProfile.statusMessage
myProfile["pictureStatus"] = scProfile.pictureStatus

cctv = {
    "cyduk":{},
    "point":{},
    "sidermem":{}
}

with open('creator.json', 'r') as fp:
    creator = json.load(fp)
with open('owner.json', 'r') as fp:
    owner = json.load(fp)
with open('admin.json', 'r') as fp:
    admin = json.load(fp)    

Setbot = codecs.open("setting.json","r","utf-8")
Setmain = json.load(Setbot)
Setbot2 = codecs.open("settings.json","r","utf-8")
settings = json.load(Setbot2)
Setbot3 = codecs.open("wait.json","r","utf-8")
wait = json.load(Setbot3)
Setbot4 = codecs.open("read.json","r","utf-8")
read = json.load(Setbot4)

mulai = time.time()

msg_dict = {}
msg_dict1 = {}

tz = pytz.timezone("Asia/Jakarta")
timeNow = datetime.now(tz=tz)


def download_page(url):
    version = (3,0)
    cur_version = sys.version_info
    if cur_version >= version:     
        import urllib,request
        try:
            headers = {}
            headers['User-Agent'] = "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36"
            req = urllib,request.Request(url, headers = headers)
            resp = urllib,request.urlopen(req)
            respData = str(resp.read())
            return respData
        except Exception as e:
            print(str(e))
    else:                        
        import urllib2
        try:
            headers = {}
            headers['User-Agent'] = "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.17 (KHTML, like Gecko) Chrome/24.0.1312.27 Safari/537.17"
            req = urllib2.Request(url, headers = headers)
            response = urllib2.urlopen(req)
            page = response.read()
            return page
        except:
            return"Page Not found"
            
def cTime_to_datetime(unixtime):
    return datetime.fromtimestamp(int(str(unixtime)[:len(str(unixtime))-3]))
    
def dt_to_str(dt):
    return dt.strftime('%H:%M:%S')

def delete_log():
    ndt = datetime.now()
    for data in msg_dict:
        if (datetime.utcnow() - cTime_to_datetime(msg_dict[data]["createdTime"])) > datetime.timedelta(1):
            del msg_dict[msg_id]

def atend():
    print("Saving")
    with open("Log_data.json","w",encoding='utf8') as f:
        json.dump(msg_dict, f, ensure_ascii=False, indent=4,separators=(',', ': '))
    print("BYE")

def _images_get_all_items(page):
    items = []
    while True:
        item, end_content = _images_get_next_item(page)
        if item == "no_links":
            break
        else:
            items.append(item)      
            time.sleep(0.1)        
            page = page[end_content:]
    return items
    
def backupData():
    try:
        backup1 = Setmain
        f = codecs.open('setting.json','w','utf-8')
        json.dump(backup1, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup2 = settings
        f = codecs.open('settings.json','w','utf-8')
        json.dump(backup2, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup3 = wait
        f = codecs.open('wait.json','w','utf-8')
        json.dump(backup3, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup4 = read
        f = codecs.open('read.json','w','utf-8')
        json.dump(backup4, f, sort_keys=True, indent=4, ensure_ascii=False)        
        return True
    except Exception as error:
        logError(error)
        return False     

def restartBot():
    backupData()
    python = sys.executable
    os.execl(python, python, *sys.argv)

def waktu(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours, 24)
    return '%02d Hari %02d Jam %02d Menit %02d Detik' % (days, hours, mins, secs)

def runtime(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours, 24)
    return '%02d Hari %02d Jam %02d Menit %02d Detik' % (days, hours, mins, secs)

def mentionMembers1(to, mid):
    try:
        arrData = ""
        textx = "╭━━━━━━━━━━━━━━━━━━━━╮\n├ ASSALAMUALAIKUM WR WB \n├ ☠ ABSEN JOMBLO [ {} ] ORANG☠\n├━━━━━━━━━━━━━━━━━━━━\n├[1.]☠".format(str(len(mid)))
        arr = []
        no = 1
        num = 2
        for i in mid:
            mention = "@panduchyaa\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention
            if no < len(mid):
                no += 1
                textx += "├[%i.]☠  " % (num)
                num=(num+1)
            else:
                try:
                    no = "\n╚☠ •➤[ {} ]".format(str(line.getGroup(to).name))
                except:
                    no = "\n╚☠ •➤[ Success ]"
        ais.sendMessage(to, textx+"╰━━━━━━━━JOMBLO━━━━━━━━━╯", {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        logError(error)
def siderMembers(to, mid):
    try:
        arrData = ""
        textx = "Total Sider User「{}」\nHaii ".format(str(len(mid)))
        arr = []
        no = 1
        num = 2
        for i in mid:
            mention = "@x\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention+wait["mention"]
            if no < len(mid):
                no += 1
                textx += "%i. " % (num)
                num=(num+1)
            else:
                try:
                    no = "\n┗━━[ {} ]".format(str(ais.getGroup(to).name))
                except:
                    no = "\n┗━━[ Success ]"
        ais.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        ais.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def welcomeMembers(to, mid):
    try:
        arrData = ""
        textx = "Total Member Masuk「{}」\nHaii  ".format(str(len(mid)))
        arr = []
        no = 1
        num = 2
        for i in mid:
            ginfo = ais.getGroup(to)
            mention = "@x\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention+wait["welcome"]+"\nDi group "+str(ginfo.name)
            if no < len(mid):
                no += 1
                textx += "%i " % (num)
                num=(num+1)
            else:
                try:
                    no = "\n┗━━[ {} ]".format(str(ais.getGroup(to).name))
                except:
                    no = "\n┗━━[ Success ]"
        ais.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        ais.sendMessage(to, "[ INFO ] Error :\n" + str(error))
        
def leaveMembers(to, mid):
    try:
        arrData = ""
        textx = "Total Member baper「{}」\nByee  ".format(str(len(mid)))
        arr = []
        no = 1
        num = 2
        for i in mid:
            ginfo = ais.getGroup(to)
            mention = "@x\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention+wait["leave"]+"\nDari group "+str(ginfo.name)
            if no < len(mid):
                no += 1
                textx += "%i " % (num)
                num=(num+1)
            else:
                try:
                    no = "\n┗━━[ {} ]".format(str(ais.getGroup(to).name))
                except:
                    no = "\n┗━━[ Success ]"
        ais.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        ais.sendMessage(to, "[ INFO ] Error :\n" + str(error))        

def sendMention(to, mid, firstmessage):
    try:
        arrData = ""
        text = "%s " %(str(firstmessage))
        arr = []
        mention = "@x \n"
        slen = str(len(text))
        elen = str(len(text) + len(mention) - 1)
        arrData = {'S':slen, 'E':elen, 'M':mid}
        arr.append(arrData)
        today = datetime.today()
        future = datetime(2018,3,1)
        hari = (str(future - today))
        comma = hari.find(",")
        hari = hari[:comma]
        teman = ais.getAllContactIds()
        gid = ais.getGroupIdsJoined()
        tz = pytz.timezone("Asia/Jakarta")
        timeNow = datetime.now(tz=tz)
        eltime = time.time() - mulai
        bot = runtime(eltime)
        text += mention+"◐ Jam : "+datetime.strftime(timeNow,'%H:%M:%S')+" Wib\n=  Group : "+str(len(gid))+"\n=  Teman : "+str(len(teman))+"\n=  Expired : In "+hari+"\n=  Version : Python3\n=  Tanggal : "+datetime.strftime(timeNow,'%Y-%m-%d')+"\n=  Runtime : \n • "+bot
        ais.sendMessage(to, text, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        ais.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def command(text):
    pesan = text.lower()
    if pesan.startswith(Setmain["keyCommand"]):
        cmd = pesan.replace(Setmain["keyCommand"],"")
    else:
        cmd = "command"
    return cmd


def infomeme():
    helpMessage2 = """
╔════════════╗
                   MERANA
╚════════════╝
╔════════════╗
           HELP PROTECT
╠════════════╝
╠❂➣ allpro on/off
╠❂➣ invitebot (invite asist)
╠❂➣ joinall
╠❂➣ byeall
╠❂➣ js in/out
╠❂➣ limit (cek limit)
╠❂➣ blc (cek blacklist)
╠❂➣ clearban (hapus blacklist)
╠❂➣ foto induk
╠❂➣ fotobot
╠❂➣ upg1foto
╠❂➣ upg2foto
╠❂➣ myname (nama)
╠❂➣ name1-7: (nama)
╠❂➣ namegs: (nama)
╠❂➣ namejs: (nama)
╠❂➣ tag/bro (mention member)
╠❂➣ tag: (nomor grup)
╠❂➣ gruplist
╠❂➣ spbot (speed assist)
╠❂➣ invitelist
╠❂➣ url grup
╠❂➣ close 
╠❂➣ respon
╠❂➣ status
╠❂➣ reject
╠❂➣ MERANA PROTECT
╚════════════╝
"""
    return helpMessage2

def bot(op):
    global time
    global ast
    global groupParam
    try:
        if op.type == 0:
            return
        
        if op.type == 11:
            if wait["qr"] == True:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    Z = ais.getGroup(op.param1)
                    if Z.preventedJoinByTicket == False:
                        Z.preventedJoinByTicket = True
                        wait["blacklist"][op.param2] = True
                        try:
                            a1.kickoutFromGroup(op.param1,[op.param2])
                            a1.updateGroup(Z)
                        except:
                            try:
                                a2.kickoutFromGroup(op.param1,[op.param2])
                                a2.updateGroup(Z)
                            except:
                                try:
                                    a3.kickoutFromGroup(op.param1,[op.param2])
                                    a3.updateGroup(Z)
                                except:
                                    try:
                                        a4.kickoutFromGroup(op.param1,[op.param2])
                                        a4.updateGroup(Z)
                                    except:
                                        try:
                                            a5.kickoutFromGroup(op.param1,[op.param2])
                                            a5.updateGroup(Z)
                                        except:
                                            try: 
                                                a5.kickoutFromGroup(op.param1,[op.param2])                                            
                                                a5.updateGroup(Z)
                                            except:
                                                pass
                        else:pass
        if op.type == 11:
            if op.param2 in wait["blacklist"]:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    G = ais.getGroup(op.param1)
                    G.preventedJoinByTicket = True
                    try:
                        a5.updateGroup(G)
                        a5.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            a5.updateGroup(G)
                            a5.kickoutFromGroup(op.param1,[op.param2])
                        except:
                            try:
                                a1.updateGroup(G)
                                a1.kickoutFromGroup(op.param1,[op.param2])
                            except:
                                try:
                                    a2.updateGroup(G)
                                    a2.kickoutFromGroup(op.param1,[op.param2])
                                except:
                                    try:
                                        a3.updateGroup(G)
                                        a3.kickoutFromGroup(op.param1,[op.param2])
                                    except:
                                        try:
                                            a4.updateGroup(G)
                                            a4.kickoutFromGroup(op.param1,[op.param2])
                                        except:
                                            pass
                else:pass
        if op.type == 11: 
            if op.param2 in wait["blacklist"]:
                try:
                    random.choice(ABC).kickoutFromGroup(op.param1,[op.param2])                   
                    print ("BLACKLIST KICK 11")
                except:
                    pass

        if op.type == 13:
            if mid in op.param3:
                if wait["autoLeave"] == True:
                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                        ais.acceptGroupInvitation(op.param1)
                        ginfo = ais.getGroup(op.param1)
                        ais.leaveGroup(op.param1)
                    else:
                        ais.acceptGroupInvitation(op.param1)
                        ginfo = ais.getGroup(op.param1)
        if op.type == 13:
            if mid in op.param3:
                if wait["autoJoin"] == True:
                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                        ais.acceptGroupInvitation(op.param1)
                        ginfo = ais.getGroup(op.param1)
                    else:
                        ais.acceptGroupInvitation(op.param1)
                        ginfo = ais.getGroup(op.param1)
            if Amid in op.param3:
                if wait["autoJoin"] == True:
                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                        a1.acceptGroupInvitation(op.param1)
                        ginfo = a1.getGroup(op.param1)
                        a1.leaveGroup(op.param1)
                    else:
                        a1.acceptGroupInvitation(op.param1)
                        ginfo = a1.getGroup(op.param1)
            if Bmid in op.param3:
                if wait["autoJoin"] == True:
                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                        a2.acceptGroupInvitation(op.param1)
                        ginfo = a2.getGroup(op.param1)
                        a2.leaveGroup(op.param1)
                    else:
                        a2.acceptGroupInvitation(op.param1)
                        ginfo = a2.getGroup(op.param1)
            if Cmid in op.param3:
                if wait["autoJoin"] == True:
                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                        a3.acceptGroupInvitation(op.param1)
                        ginfo = a3.getGroup(op.param1)
                        a3.leaveGroup(op.param1)
                    else:
                        a3.acceptGroupInvitation(op.param1)
                        ginfo = a3.getGroup(op.param1)
            if Dmid in op.param3:
                if wait["autoJoin"] == True:
                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                        a4.acceptGroupInvitation(op.param1)
                        ginfo = a4.getGroup(op.param1)
                        a4.leaveGroup(op.param1)
                    else:
                        a4.acceptGroupInvitation(op.param1)
                        ginfo = a4.getGroup(op.param1)
            if Emid in op.param3:
                if wait["autoJoin"] == True:
                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                        a5.acceptGroupInvitation(op.param1)
                        ginfo = a5.getGroup(op.param1)
                        a5.leaveGroup(op.param1)
                    else:
                        a5.acceptGroupInvitation(op.param1)
                        ginfo = a5.getGroup(op.param1)

        if op.type == 13:
            if wait["vit"] == True:
                if op.param2 not in Bots and op.param2 not in admin and op.param2 not in staff:
                    try:
                        inv1 = op.param3.replace('\x1e',',')
                        inv2 = inv1.split(',')
                        for _mid in inv2:
                            if _mid not in Bots and _mid not in admin and _mid not in staff:
                                a1.cancelGroupInvitation(op.param1,[_mid])
                                a1.kickoutFromGroup(op.param1,[op.param2])
                                wait["blacklist"][op.param2] = True
                    except:
                        try:
                            inv1 = op.param3.replace('\x1e',',')
                            inv2 = inv1.split(',')
                            for _mid in inv2:
                                if _mid not in Bots and _mid not in admin and _mid not in staff:
                                    a2.cancelGroupInvitation(op.param1,[_mid])
                                    a2.kickoutFromGroup(op.param1,[op.param2])
                                    wait["blacklist"][op.param2] = True
                        except:
                            try:
                                inv1 = op.param3.replace('\x1e',',')
                                inv2 = inv1.split(',')
                                for _mid in inv2:
                                    if _mid not in Bots and _mid not in admin and _mid not in staff:
                                        a3.cancelGroupInvitation(op.param1,[_mid])
                                        a3.kickoutFromGroup(op.param1,[op.param2])
                                        wait["blacklist"][op.param2] = True
                            except:
                                try:
                                    inv1 = op.param3.replace('\x1e',',')
                                    inv2 = inv1.split(',')
                                    for _mid in inv2:
                                        if _mid not in Bots and _mid not in admin and _mid not in staff:
                                            a4.cancelGroupInvitation(op.param1,[_mid])
                                            a4.kickoutFromGroup(op.param1,[op.param2])
                                            wait["blacklist"][op.param2] = True
                                except:
                                    try:
                                        inv1 = op.param3.replace('\x1e',',')
                                        inv2 = inv1.split(',')
                                        for _mid in inv2:
                                            if _mid not in Bots and _mid not in admin and _mid not in staff:
                                                a5.cancelGroupInvitation(op.param1,[_mid])
                                                a5.kickoutFromGroup(op.param1,[op.param2])
                                                wait["blacklist"][op.param2] = True
                                    except:
                                        pass

        if op.type == 13:
            if wait["backupx"] == True:
                if op.param2 in Bots or op.param2 in owner or op.param2 in admin or op.param2 in staff:
                    pass
                else:
                    try:
                        if op.param3 in Bots or op.param3 in owner or op.param3 in admin or op.param2 in staff:
                            pass
                        else:
                            if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                                try:
                                    inv1 = op.param3.replace('\x1e',',')
                                    inv2 = inv1.split(',')
                                    for _mid in inv2:
                                        if _mid not in Bots and _mid not in owner and _mid not in admin and _mid not in staff:
                                            a1.cancelGroupInvitation(op.param1,[_mid])
                                            a1.kickoutFromGroup(op.param1,[op.param2])
                                            wait["blacklist"][op.param2] = True
                                except:
                                    try:
                                        inv1 = op.param3.replace('\x1e',',')
                                        inv2 = inv1.split(',')
                                        for _mid in inv2:
                                            if _mid not in Bots and _mid not in owner and _mid not in admin and _mid not in staff:
                                                a2.cancelGroupInvitation(op.param1,[_mid])
                                                a2.kickoutFromGroup(op.param1,[op.param2])
                                                wait["blacklist"][op.param2] = True
                                    except:
                                        try:
                                            inv1 = op.param3.replace('\x1e',',')
                                            inv2 = inv1.split(',')
                                            for _mid in inv2:
                                                if _mid not in Bots and _mid not in owner and _mid not in admin and _mid not in staff:
                                                    a3.cancelGroupInvitation(op.param1,[_mid])
                                                    a3.kickoutFromGroup(op.param1,[op.param2])
                                                    wait["blacklist"][op.param2] = True
                                        except:
                                            try:
                                                inv1 = op.param3.replace('\x1e',',')
                                                inv2 = inv1.split(',')
                                                for _mid in inv2:
                                                    if _mid not in Bots and _mid not in owner and _mid not in admin and _mid not in staff:
                                                        a4.cancelGroupInvitation(op.param1,[_mid])
                                                        a4.kickoutFromGroup(op.param1,[op.param2])
                                                        wait["blacklist"][op.param2] = True
                                            except:
                                                try:
                                                    inv1 = op.param3.replace('\x1e',',')
                                                    inv2 = inv1.split(',')
                                                    for _mid in inv2:
                                                        if _mid not in Bots and _mid not in owner and _mid not in admin and _mid not in staff:
                                                            a5.cancelGroupInvitation(op.param1,[_mid])
                                                            a5.kickoutFromGroup(op.param1,[op.param2])
                                                            wait["blacklist"][op.param2] = True
                                                except:
                                                    try:
                                                        inv1 = op.param3.replace('\x1e',',')
                                                        inv2 = inv1.split(',')
                                                        for _mid in inv2:
                                                            if _mid not in Bots and _mid not in owner and _mid not in admin and _mid not in staff:
                                                                a5.cancelGroupInvitation(op.param1,[_mid])
                                                                a5.kickoutFromGroup(op.param1,[op.param2])
                                                                wait["blacklist"][op.param2] = True
                                                    except:
                                                        pass
                            else:pass
                    except:
                        pass

        if op.type == 13:
            if op.param2 in wait["blacklist"]:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    try:
                        group = random.choice(ABC).getGroup(op.param1)
                        gMembMids = [contact.mid for contact in group.invitee]
                        for _mid in gMembMids:
                            if _mid in wait["blacklist"]:
                                random.choice(ABC).cancelGroupInvitation(op.param1,[_mid])
                                random.choice(ABC).kickoutFromGroup(op.param1,[op.param2])
                    except:
                        pass

        if op.type == 13:
            if op.param3 in wait["blacklist"]:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    try:
                        group = random.choice(ABC).getGroup(op.param1)
                        gMembMids = [contact.mid for contact in group.invitee]
                        for _mid in gMembMids:
                            if _mid in wait["blacklist"]:
                                random.choice(ABC).cancelGroupInvitation(op.param1,[_mid])
                                random.choice(ABC).kickoutFromGroup(op.param1,[op.param2])
                    except:
                        pass

        if op.type == 13: 
            if op.param2 in wait["blacklist"]:
                try:
                    random.choice(ABC).kickoutFromGroup(op.param1,[op.param2])                   
                    print ("BLACKLIST KICK 13")
                except:
                    pass

        if op.type == 15:
            if op.param1 in welcome:
                if op.param2 in Bots:
                    pass
                ginfo = ais.getGroup(op.param1)
                contact = ais.getContact(op.param2).picturePath
                image = 'http://dl.profile.line.naver.jp'+contact
                leaveMembers(op.param1, [op.param2])
                ais.sendImageWithURL(op.param1, image)
        if op.type in [17]: 
            if op.param2 in wait["blacklist"]:
                try:
                    random.choice(ABC).kickoutFromGroup(op.param1,[op.param2])                   
                    print ("BLACKLIST KICK 17")
                except:
                    pass
        if op.type == 17:
            if op.param1 in welcome:
                if op.param2 in Bots:
                    pass
                ginfo = ais.getGroup(op.param1)
                contact = ais.getContact(op.param2)
                image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                welcomeMembers(op.param1, [op.param2])
                ais.sendImageWithURL(op.param1, image)

        if op.type == 32:
            if wait["cancel"] == True:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    wait['blacklist'][op.param2] = True
                    random.choice(ABC).kickoutFromGroup(op.param1,[op.param2])
                    random.choice(ABC).inviteIntoGroup(op.param1,[mid,Amid,Bmid,Cmid,Dmid,Emid,Xmid])

        if op.type == 32:
            if wait["cjs"] == True:
                if op.param3 in Bots:    
                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                        wait["blacklist"][op.param2] = True
                        try:
                            if op.param3 not in wait["blacklist"]:
                                random.choice(ABC).kickoutFromGroup(op.param1,[op.param2])
                                ais.inviteIntoGroup(op.param1,[Amid,Bmid,Cmid,Dmid,Emid,Xmid])		
                                G.preventedJoinByTicket = True
                                random.choice(ABC).updateGroup(G)
                        except:
                            pass
                    return

        if op.type == 17:
            if wait["joinan"] == True:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    wait["blacklist"][op.param2] = True
                    try:
                        if op.param3 not in wait["blacklist"]:
                        	a1.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            if op.param3 not in wait["blacklist"]:
                                a2.kickoutFromGroup(op.param1,[op.param2])
                        except:
                            try:
                                if op.param3 not in wait["blacklist"]:
                                    a3.kickoutFromGroup(op.param1,[op.param2])
                            except:
                                try:
                                    if op.param3 not in wait["blacklist"]:
                                        a4.kickoutFromGroup(op.param1,[op.param2])
                                except:
                                    try:
                                        if op.param3 not in wait["blacklist"]:
                                            a5.kickoutFromGroup(op.param1,[op.param2])
                                    except:
                                        try:
                                            if op.param3 not in wait["blacklist"]:
                                                a5.kickoutFromGroup(op.param1,[op.param2])
                                        except:
                                            pass
                return

        if op.type == 0:
            return
        if op.type == 5:
            if wait["autoAdd"] == True:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    if (wait["message"] in [" "," ","\n",None]):
                        pass
                    else:
                        ais.sendMessage(op.param1, wait["message"])

#===============================#
        if op.type == 19:
            if wait["js"] == True:
                if mid in op.param3:
                    if op.param2 not in Bots and op.param2 not in Saints and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                        try:
                            ajs.acceptGroupInvitation(op.param1)
                            ajs.kickoutFromGroup(op.param1,[op.param2])
                            G = ajs.getGroup(op.param1)
                            G.preventedJoinByTicket = False
                            ajs.updateGroup(G)
                            Ticket = ajs.reissueGroupTicket(op.param1)
                            time.sleep(0.02)
                            ais.acceptGroupInvitationByTicket(op.param1,Ticket)
                            time.sleep(0.02)
                            a1.acceptGroupInvitationByTicket(op.param1,Ticket)
                            time.sleep(0.02)
                            a2.acceptGroupInvitationByTicket(op.param1,Ticket)
                            time.sleep(0.02)
                            a3.acceptGroupInvitationByTicket(op.param1,Ticket)	
                            time.sleep(0.02)
                            a4.acceptGroupInvitationByTicket(op.param1,Ticket)
                            time.sleep(0.02)
                            a5.acceptGroupInvitationByTicket(op.param1,Ticket)
                            wait["blacklist"][op.param2] = True
                            ajs.leaveGroup(op.param1)
                            ais.inviteIntoGroup(op.param1,[Xmid])                                                  
                        except:
                            pass
                            
#===============================#
        if op.type == 19:
            if wait["kick"] == True:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    wait["blacklist"][op.param2] = True
                    random.choice(ABC).kickoutFromGroup(op.param1,[op.param2])
                else:
                    pass

#===============================#
        if op.type == 19:
            if Amid in op.param3:
                if op.param2 in Bots:
                    pass
                if op.param2 in owner:
                    pass
                if op.param2 in admin:
                    pass
                if op.param2 in staff:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    try:
                        a2.kickoutFromGroup(op.param1,[op.param2])
                        a2.findAndAddContactsByMid(op.param3)
                        a2.inviteIntoGroup(op.param1,[Amid,Cmid,Dmid,Emid,Emid])
                        a1.acceptGroupInvitation(op.param1)
                        a3.acceptGroupInvitation(op.param1)
                        a4.acceptGroupInvitation(op.param1)
                        a5.acceptGroupInvitation(op.param1)
                        group = a1.getGroup(op.param1)
                        nama = [contact.mid for contact in group.members]
                        for x in nama:
                            if x in wait["blacklist"]:
                                a1.kickoutFromGroup(op.param1,[x])
                    except:
                        try:
                            a3.kickoutFromGroup(op.param1,[op.param2])
                            a3.findAndAddContactsByMid(op.param3)
                            a3.inviteIntoGroup(op.param1,[Amid,Bmid,Dmid,Emid,Emid])
                            a1.acceptGroupInvitation(op.param1)
                            a2.acceptGroupInvitation(op.param1)
                            a4.acceptGroupInvitation(op.param1)
                            a5.acceptGroupInvitation(op.param1)
                            group = a1.getGroup(op.param1)
                            nama = [contact.mid for contact in group.members]
                            for x in nama:
                                if x in wait["blacklist"]:
                                    a1.kickoutFromGroup(op.param1,[x])
                        except:
                            try:
                                a4.kickoutFromGroup(op.param1,[op.param2])
                                a4.findAndAddContactsByMid(op.param3)
                                a4.inviteIntoGroup(op.param1,[Amid,Bmid,Cmid,Emid,Emid])
                                a1.acceptGroupInvitation(op.param1)
                                a2.acceptGroupInvitation(op.param1)
                                a3.acceptGroupInvitation(op.param1)
                                a5.acceptGroupInvitation(op.param1)
                                group = a1.getGroup(op.param1)
                                nama = [contact.mid for contact in group.members]
                                for x in nama:
                                    if x in wait["blacklist"]:
                                        a1.kickoutFromGroup(op.param1,[x])
                            except:
                                try:
                                    a5.kickoutFromGroup(op.param1,[op.param2])
                                    a5.findAndAddContactsByMid(op.param3)
                                    a5.inviteIntoGroup(op.param1,[Amid,Bmid,Cmid,Dmid,Emid])
                                    a1.acceptGroupInvitation(op.param1)
                                    a2.acceptGroupInvitation(op.param1)
                                    a3.acceptGroupInvitation(op.param1)
                                    a4.acceptGroupInvitation(op.param1)
                                    a5.acceptGroupInvitation(op.param1)
                                    group = a1.getGroup(op.param1)
                                    nama = [contact.mid for contact in group.members]
                                    for x in nama:
                                        if x in wait["blacklist"]:
                                            a1.kickoutFromGroup(op.param1,[x])
                                except:
                                    try:
                                        a5.kickoutFromGroup(op.param1,[op.param2])
                                        a5.findAndAddContactsByMid(op.param3)
                                        a5.inviteIntoGroup(op.param1,[Amid,Bmid,Cmid,Dmid,Emid])
                                        a1.acceptGroupInvitation(op.param1)
                                        a2.acceptGroupInvitation(op.param1)
                                        a3.acceptGroupInvitation(op.param1)
                                        a4.acceptGroupInvitation(op.param1)
                                        group = a1.getGroup(op.param1)
                                        nama = [contact.mid for contact in group.members]
                                        for x in nama:
                                            if x in wait["blacklist"]:
                                                a1.kickoutFromGroup(op.param1,[x])
                                    except:
                                        pass

                return

            if Bmid in op.param3:
                if op.param2 in Bots:
                    pass
                if op.param2 in owner:
                    pass
                if op.param2 in admin:
                    pass
                if op.param2 in staff:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    try:
                        a3.kickoutFromGroup(op.param1,[op.param2])
                        a3.findAndAddContactsByMid(op.param3)
                        a3.inviteIntoGroup(op.param1,[Bmid,Dmid,Emid,Emid,Amid])
                        a2.acceptGroupInvitation(op.param1)
                        a1.acceptGroupInvitation(op.param1)
                        a4.acceptGroupInvitation(op.param1)
                        a5.acceptGroupInvitation(op.param1)
                        a5.acceptGroupInvitation(op.param1)
                        group = a2.getGroup(op.param1)
                        nama = [contact.mid for contact in group.members]
                        for x in nama:
                            if x in wait["blacklist"]:
                                a2.kickoutFromGroup(op.param1,[x])
                    except:
                        try:
                            a4.kickoutFromGroup(op.param1,[op.param2])
                            a4.findAndAddContactsByMid(op.param3)
                            a4.inviteIntoGroup(op.param1,[Bmid,Cmid,Emid,Emid,Amid])
                            a2.acceptGroupInvitation(op.param1)
                            a1.acceptGroupInvitation(op.param1)
                            a3.acceptGroupInvitation(op.param1)
                            a5.acceptGroupInvitation(op.param1)
                            a5.acceptGroupInvitation(op.param1)
                            group = a2.getGroup(op.param1)
                            nama = [contact.mid for contact in group.members]
                            for x in nama:
                                if x in wait["blacklist"]:
                                    a2.kickoutFromGroup(op.param1,[x])
                        except:
                            try:
                                a5.kickoutFromGroup(op.param1,[op.param2])
                                a5.findAndAddContactsByMid(op.param3)
                                a5.inviteIntoGroup(op.param1,[Bmid,Cmid,Dmid,Emid,Amid])
                                a2.acceptGroupInvitation(op.param1)
                                a1.acceptGroupInvitation(op.param1)
                                a3.acceptGroupInvitation(op.param1)
                                a4.acceptGroupInvitation(op.param1)
                                a5.acceptGroupInvitation(op.param1)
                                group = a2.getGroup(op.param1)
                                nama = [contact.mid for contact in group.members]
                                for x in nama:
                                    if x in wait["blacklist"]:
                                        a2.kickoutFromGroup(op.param1,[x])
                            except:
                                try:
                                    a5.kickoutFromGroup(op.param1,[op.param2])
                                    a5.findAndAddContactsByMid(op.param3)
                                    a5.inviteIntoGroup(op.param1,[Bmid,Cmid,Dmid,Emid,Amid])
                                    a2.acceptGroupInvitation(op.param1)
                                    a1.acceptGroupInvitation(op.param1)
                                    a3.acceptGroupInvitation(op.param1)
                                    a4.acceptGroupInvitation(op.param1)
                                    a5.acceptGroupInvitation(op.param1)
                                    group = a2.getGroup(op.param1)
                                    nama = [contact.mid for contact in group.members]
                                    for x in nama:
                                        if x in wait["blacklist"]:
                                            a2.kickoutFromGroup(op.param1,[x])
                                except:
                                    try:
                                        a1.kickoutFromGroup(op.param1,[op.param2])
                                        a1.findAndAddContactsByMid(op.param3)
                                        a1.inviteIntoGroup(op.param1,[Bmid,Cmid,Dmid,Emid,Emid])
                                        a2.acceptGroupInvitation(op.param1)
                                        a3.acceptGroupInvitation(op.param1)
                                        a4.acceptGroupInvitation(op.param1)
                                        a5.acceptGroupInvitation(op.param1)
                                        a5.acceptGroupInvitation(op.param1)
                                        group = a2.getGroup(op.param1)
                                        nama = [contact.mid for contact in group.members]
                                        for x in nama:
                                            if x in wait["blacklist"]:
                                                a2.kickoutFromGroup(op.param1,[x])
                                    except:
                                        pass

                return

            if Cmid in op.param3:
                if op.param2 in Bots:
                    pass
                if op.param2 in owner:
                    pass
                if op.param2 in admin:
                    pass
                if op.param2 in staff:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    try:
                        a4.kickoutFromGroup(op.param1,[op.param2])
                        a4.findAndAddContactsByMid(op.param3)
                        a4.inviteIntoGroup(op.param1,[Cmid,Emid,Emid,Amid,Bmid])
                        a3.acceptGroupInvitation(op.param1)
                        a1.acceptGroupInvitation(op.param1)
                        a2.acceptGroupInvitation(op.param1)
                        a5.acceptGroupInvitation(op.param1)
                        a5.acceptGroupInvitation(op.param1)
                        group = a3.getGroup(op.param1)
                        nama = [contact.mid for contact in group.members]
                        for x in nama:
                            if x in wait["blacklist"]:
                                a3.kickoutFromGroup(op.param1,[x])
                    except:
                        try:
                            a5.kickoutFromGroup(op.param1,[op.param2])
                            a5.findAndAddContactsByMid(op.param3)
                            a5.inviteIntoGroup(op.param1,[Cmid,Dmid,Emid,Amid,Bmid])
                            a3.acceptGroupInvitation(op.param1)
                            a1.acceptGroupInvitation(op.param1)
                            a2.acceptGroupInvitation(op.param1)
                            a4.acceptGroupInvitation(op.param1)
                            a5.acceptGroupInvitation(op.param1)
                            group = a3.getGroup(op.param1)
                            nama = [contact.mid for contact in group.members]
                            for x in nama:
                                if x in wait["blacklist"]:
                                    a3.kickoutFromGroup(op.param1,[x])
                        except:
                            try:
                                a5.kickoutFromGroup(op.param1,[op.param2])
                                a5.findAndAddContactsByMid(op.param3)
                                a5.inviteIntoGroup(op.param1,[Cmid,Dmid,Emid,Amid,Bmid])
                                a3.acceptGroupInvitation(op.param1)
                                a1.acceptGroupInvitation(op.param1)
                                a2.acceptGroupInvitation(op.param1)
                                a4.acceptGroupInvitation(op.param1)
                                a5.acceptGroupInvitation(op.param1)
                                group = a3.getGroup(op.param1)
                                nama = [contact.mid for contact in group.members]
                                for x in nama:
                                    if x in wait["blacklist"]:
                                        a3.kickoutFromGroup(op.param1,[x])
                            except:
                                try:
                                    a1.kickoutFromGroup(op.param1,[op.param2])
                                    a1.findAndAddContactsByMid(op.param3)
                                    a1.inviteIntoGroup(op.param1,[Cmid,Dmid,Emid,Emid,Bmid])
                                    a3.acceptGroupInvitation(op.param1)
                                    a2.acceptGroupInvitation(op.param1)
                                    a4.acceptGroupInvitation(op.param1)
                                    a5.acceptGroupInvitation(op.param1)
                                    a5.acceptGroupInvitation(op.param1)
                                    group = a3.getGroup(op.param1)
                                    nama = [contact.mid for contact in group.members]
                                    for x in nama:
                                        if x in wait["blacklist"]:
                                            a3.kickoutFromGroup(op.param1,[x])
                                except:
                                    try:
                                        a2.kickoutFromGroup(op.param1,[op.param2])
                                        a2.findAndAddContactsByMid(op.param3)
                                        a2.inviteIntoGroup(op.param1,[Cmid,Dmid,Emid,Amid,Emid])
                                        a3.acceptGroupInvitation(op.param1)
                                        a1.acceptGroupInvitation(op.param1)
                                        a4.acceptGroupInvitation(op.param1)
                                        a5.acceptGroupInvitation(op.param1)
                                        a5.acceptGroupInvitation(op.param1)
                                        group = a3.getGroup(op.param1)
                                        nama = [contact.mid for contact in group.members]
                                        for x in nama:
                                            if x in wait["blacklist"]:
                                                a3.kickoutFromGroup(op.param1,[x])
                                    except:
                                        pass

                return

            if Dmid in op.param3:
                if op.param2 in Bots:
                    pass
                if op.param2 in owner:
                    pass
                if op.param2 in admin:
                    pass
                if op.param2 in staff:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    try:
                        a5.kickoutFromGroup(op.param1,[op.param2])
                        a5.findAndAddContactsByMid(op.param3)
                        a5.inviteIntoGroup(op.param1,[Dmid,Emid,Amid,Bmid,Cmid])
                        a4.acceptGroupInvitation(op.param1)
                        a1.acceptGroupInvitation(op.param1)
                        a2.acceptGroupInvitation(op.param1)
                        a3.acceptGroupInvitation(op.param1)
                        a5.acceptGroupInvitation(op.param1)
                        group = a4.getGroup(op.param1)
                        nama = [contact.mid for contact in group.members]
                        for x in nama:
                            if x in wait["blacklist"]:
                                a4.kickoutFromGroup(op.param1,[x])
                    except:
                        try:
                            a5.kickoutFromGroup(op.param1,[op.param2])
                            a5.findAndAddContactsByMid(op.param3)
                            a5.inviteIntoGroup(op.param1,[Dmid,Emid,Emid,Amid,Cmid])
                            a4.acceptGroupInvitation(op.param1)
                            a1.acceptGroupInvitation(op.param1)
                            a2.acceptGroupInvitation(op.param1)
                            a3.acceptGroupInvitation(op.param1)
                            a5.acceptGroupInvitation(op.param1)
                            group = a4.getGroup(op.param1)
                            nama = [contact.mid for contact in group.members]
                            for x in nama:
                                if x in wait["blacklist"]:
                                    a4.kickoutFromGroup(op.param1,[x])
                        except:
                            try:
                                a1.kickoutFromGroup(op.param1,[op.param2])
                                a1.findAndAddContactsByMid(op.param3)
                                a1.inviteIntoGroup(op.param1,[Dmid,Emid,Emid,Bmid,Cmid])
                                a4.acceptGroupInvitation(op.param1)
                                a2.acceptGroupInvitation(op.param1)
                                a3.acceptGroupInvitation(op.param1)
                                a5.acceptGroupInvitation(op.param1)
                                a5.acceptGroupInvitation(op.param1)
                                group = a4.getGroup(op.param1)
                                nama = [contact.mid for contact in group.members]
                                for x in nama:
                                    if x in wait["blacklist"]:
                                        a4.kickoutFromGroup(op.param1,[x])
                            except:
                                try:
                                    a2.kickoutFromGroup(op.param1,[op.param2])
                                    a2.findAndAddContactsByMid(op.param3)
                                    a2.inviteIntoGroup(op.param1,[Dmid,Emid,Emid,Amid,Cmid])
                                    a4.acceptGroupInvitation(op.param1)
                                    a1.acceptGroupInvitation(op.param1)
                                    a3.acceptGroupInvitation(op.param1)
                                    a5.acceptGroupInvitation(op.param1)
                                    a5.acceptGroupInvitation(op.param1)
                                    group = a4.getGroup(op.param1)
                                    nama = [contact.mid for contact in group.members]
                                    for x in nama:
                                        if x in wait["blacklist"]:
                                            a4.kickoutFromGroup(op.param1,[x])
                                except:
                                    try:
                                        a3.kickoutFromGroup(op.param1,[op.param2])
                                        a3.findAndAddContactsByMid(op.param3)
                                        a3.inviteIntoGroup(op.param1,[Dmid,Emid,Emid,Amid,Bmid])
                                        a4.acceptGroupInvitation(op.param1)
                                        a1.acceptGroupInvitation(op.param1)
                                        a2.acceptGroupInvitation(op.param1)
                                        a5.acceptGroupInvitation(op.param1)
                                        a5.acceptGroupInvitation(op.param1)
                                        group = a4.getGroup(op.param1)
                                        nama = [contact.mid for contact in group.members]
                                        for x in nama:
                                            if x in wait["blacklist"]:
                                                a4.kickoutFromGroup(op.param1,[x])
                                    except:
                                        pass

                return

            if Emid in op.param3:
                if op.param2 in Bots:
                    pass
                if op.param2 in owner:
                    pass
                if op.param2 in admin:
                    pass
                if op.param2 in staff:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    try:
                        a5.kickoutFromGroup(op.param1,[op.param2])
                        a5.findAndAddContactsByMid(op.param3)
                        a5.inviteIntoGroup(op.param1,[Emid,Amid,Bmid,Cmid,Dmid])
                        a5.acceptGroupInvitation(op.param1)
                        a1.acceptGroupInvitation(op.param1)
                        a2.acceptGroupInvitation(op.param1)
                        a3.acceptGroupInvitation(op.param1)
                        a4.acceptGroupInvitation(op.param1)
                        group = a5.getGroup(op.param1)
                        nama = [contact.mid for contact in group.members]
                        for x in nama:
                            if x in wait["blacklist"]:
                                a5.kickoutFromGroup(op.param1,[x])
                    except:
                        try:
                            a1.kickoutFromGroup(op.param1,[op.param2])
                            a1.findAndAddContactsByMid(op.param3)
                            a1.inviteIntoGroup(op.param1,[Emid,Emid,Bmid,Cmid,Dmid])
                            a5.acceptGroupInvitation(op.param1)
                            a2.acceptGroupInvitation(op.param1)
                            a3.acceptGroupInvitation(op.param1)
                            a4.acceptGroupInvitation(op.param1)
                            a5.acceptGroupInvitation(op.param1)
                            group = a5.getGroup(op.param1)
                            nama = [contact.mid for contact in group.members]
                            for x in nama:
                                if x in wait["blacklist"]:
                                    a5.kickoutFromGroup(op.param1,[x])
                        except:
                            try:
                                a2.kickoutFromGroup(op.param1,[op.param2])
                                a2.findAndAddContactsByMid(op.param3)
                                a2.inviteIntoGroup(op.param1,[Emid,Emid,Cmid,Amid,Dmid])
                                a5.acceptGroupInvitation(op.param1)
                                a1.acceptGroupInvitation(op.param1)
                                a3.acceptGroupInvitation(op.param1)
                                a4.acceptGroupInvitation(op.param1)
                                a5.acceptGroupInvitation(op.param1)
                                group = a5.getGroup(op.param1)
                                nama = [contact.mid for contact in group.members]
                                for x in nama:
                                    if x in wait["blacklist"]:
                                        a5.kickoutFromGroup(op.param1,[x])
                            except:
                                try:
                                    a3.kickoutFromGroup(op.param1,[op.param2])
                                    a3.findAndAddContactsByMid(op.param3)
                                    a3.inviteIntoGroup(op.param1,[Emid,Emid,Bmid,Amid,Dmid])
                                    a5.acceptGroupInvitation(op.param1)
                                    a1.acceptGroupInvitation(op.param1)
                                    a2.acceptGroupInvitation(op.param1)
                                    a4.acceptGroupInvitation(op.param1)
                                    a5.acceptGroupInvitation(op.param1)
                                    group = a5.getGroup(op.param1)
                                    nama = [contact.mid for contact in group.members]
                                    for x in nama:
                                        if x in wait["blacklist"]:
                                            a5.kickoutFromGroup(op.param1,[x])
                                except:
                                    try:
                                        a4.kickoutFromGroup(op.param1,[op.param2])
                                        a4.findAndAddContactsByMid(op.param3)
                                        a4.inviteIntoGroup(op.param1,[Emid,Emid,Cmid,Amid,Bmid])
                                        a5.acceptGroupInvitation(op.param1)
                                        a1.acceptGroupInvitation(op.param1)
                                        a2.acceptGroupInvitation(op.param1)
                                        a3.acceptGroupInvitation(op.param1)
                                        a5.acceptGroupInvitation(op.param1)
                                        group = a5.getGroup(op.param1)
                                        nama = [contact.mid for contact in group.members]
                                        for x in nama:
                                            if x in wait["blacklist"]:
                                                a5.kickoutFromGroup(op.param1,[x])
                                    except:
                                        pass

                return

            if Emid in op.param3:
                if op.param2 in Bots:
                    pass
                if op.param2 in owner:
                    pass
                if op.param2 in admin:
                    pass
                if op.param2 in staff:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    try:
                        a1.kickoutFromGroup(op.param1,[op.param2])
                        a1.findAndAddContactsByMid(op.param3)
                        a1.inviteIntoGroup(op.param1,[Emid,Bmid,Cmid,Dmid,Emid])
                        a5.acceptGroupInvitation(op.param1)
                        a2.acceptGroupInvitation(op.param1)
                        a3.acceptGroupInvitation(op.param1)
                        a4.acceptGroupInvitation(op.param1)
                        a5.acceptGroupInvitation(op.param1)
                        group = a5.getGroup(op.param1)
                        nama = [contact.mid for contact in group.members]
                        for x in nama:
                            if x in wait["blacklist"]:
                                a5.kickoutFromGroup(op.param1,[x])
                    except:
                        try:
                            a2.kickoutFromGroup(op.param1,[op.param2])
                            a2.findAndAddContactsByMid(op.param3)
                            a2.inviteIntoGroup(op.param1,[Emid,Amid,Cmid,Dmid,Emid])
                            a5.acceptGroupInvitation(op.param1)
                            a1.acceptGroupInvitation(op.param1)
                            a3.acceptGroupInvitation(op.param1)
                            a4.acceptGroupInvitation(op.param1)
                            a5.acceptGroupInvitation(op.param1)
                            group = a5.getGroup(op.param1)
                            nama = [contact.mid for contact in group.members]
                            for x in nama:
                                if x in wait["blacklist"]:
                                    a5.kickoutFromGroup(op.param1,[x])
                        except:
                            try:
                                a3.kickoutFromGroup(op.param1,[op.param2])
                                a3.findAndAddContactsByMid(op.param3)
                                a3.inviteIntoGroup(op.param1,[Emid,Bmid,Amid,Dmid,Emid])
                                a5.acceptGroupInvitation(op.param1)
                                a1.acceptGroupInvitation(op.param1)
                                a2.acceptGroupInvitation(op.param1)
                                a4.acceptGroupInvitation(op.param1)
                                a5.acceptGroupInvitation(op.param1)
                                group = a5.getGroup(op.param1)
                                nama = [contact.mid for contact in group.members]
                                for x in nama:
                                    if x in wait["blacklist"]:
                                        a5.kickoutFromGroup(op.param1,[x])
                            except:
                                try:
                                    a4.kickoutFromGroup(op.param1,[op.param2])
                                    a4.findAndAddContactsByMid(op.param3)
                                    a4.inviteIntoGroup(op.param1,[Emid,Bmid,Cmid,Amid,Emid])
                                    a5.acceptGroupInvitation(op.param1)
                                    a1.acceptGroupInvitation(op.param1)
                                    a2.acceptGroupInvitation(op.param1)
                                    a3.acceptGroupInvitation(op.param1)
                                    a5.acceptGroupInvitation(op.param1)
                                    group = a5.getGroup(op.param1)
                                    nama = [contact.mid for contact in group.members]
                                    for x in nama:
                                        if x in wait["blacklist"]:
                                            a5.kickoutFromGroup(op.param1,[x])
                                except:
                                    try:
                                        a5.kickoutFromGroup(op.param1,[op.param2])
                                        a5.findAndAddContactsByMid(op.param3)
                                        a5.inviteIntoGroup(op.param1,[Emid,Bmid,Cmid,Dmid,Amid])
                                        a5.acceptGroupInvitation(op.param1)
                                        a1.acceptGroupInvitation(op.param1)
                                        a2.acceptGroupInvitation(op.param1)
                                        a3.acceptGroupInvitation(op.param1)
                                        a4.acceptGroupInvitation(op.param1)
                                        group = a5.getGroup(op.param1)
                                        nama = [contact.mid for contact in group.members]
                                        for x in nama:
                                            if x in wait["blacklist"]:
                                                a5.kickoutFromGroup(op.param1,[x])
                                    except:
                                        pass
                return

            if mid in op.param3:
                if op.param2 in Bots:
                    pass
                if op.param2 in owner:
                    pass
                if op.param2 in admin:
                    pass
                if op.param2 in staff:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    try:
                        a1.kickoutFromGroup(op.param1,[op.param2])
                        a1.findAndAddContactsByMid(op.param3)
                        a1.inviteIntoGroup(op.param1,[Bmid,Cmid,Dmid,Emid,Emid])
                        ais.acceptGroupInvitation(op.param1)
                    except:
                        try:
                            a2.kickoutFromGroup(op.param1,[op.param2])
                            a2.findAndAddContactsByMid(op.param3)
                            a2.inviteIntoGroup(op.param1,[Cmid,Dmid,Emid,Emid,Amid])
                            ais.acceptGroupInvitation(op.param1)
                        except:
                            try:
                                a3.kickoutFromGroup(op.param1,[op.param2])
                                a3.findAndAddContactsByMid(op.param3)
                                a3.inviteIntoGroup(op.param1,[Bmid,Amid,Dmid,Emid,Emid])
                                ais.acceptGroupInvitation(op.param1)
                            except:
                                try:
                                    a4.kickoutFromGroup(op.param1,[op.param2])
                                    a4.findAndAddContactsByMid(op.param3)
                                    a4.inviteIntoGroup(op.param1,[Bmid,Cmid,Amid,Emid,Emid])
                                    ais.acceptGroupInvitation(op.param1)
                                except:
                                    try:
                                        a5.kickoutFromGroup(op.param1,[op.param2])
                                        a5.findAndAddContactsByMid(op.param3)
                                        a5.inviteIntoGroup(op.param1,[Bmid,Cmid,Dmid,Amid,Emid])
                                        ais.acceptGroupInvitation(op.param1)
                                    except:
                                        try:
                                            a5.kickoutFromGroup(op.param1,[op.param2])
                                            a5.findAndAddContactsByMid(op.param3)
                                            a5.inviteIntoGroup(op.param1,[Bmid,Cmid,Dmid,Emid,Amid])
                                            ais.acceptGroupInvitation(op.param1)
                                        except:
                                            pass

                return

            if owner in op.param3:
                if op.param2 in Bots:
                    pass
                if op.param2 in owner:
                    pass
                if op.param2 in admin:
                    pass
                if op.param2 in staff:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    try:
                        a1.kickoutFromGroup(op.param1,[op.param2])
                        a1.findAndAddContactsByMid(op.param1,owner)
                        a1.inviteIntoGroup(op.param1,owner)
                    except:
                        try:
                            a2.kickoutFromGroup(op.param1,[op.param2])
                            a2.findAndAddContactsByMid(op.param1,owner)
                            a2.inviteIntoGroup(op.param1,owner)
                        except:
                            try:
                                a3.kickoutFromGroup(op.param1,[op.param2])
                                a3.findAndAddContactsByMid(op.param1,owner)
                                a3.inviteIntoGroup(op.param1,owner)
                            except:
                                try:
                                    a4.kickoutFromGroup(op.param1,[op.param2])
                                    a4.findAndAddContactsByMid(op.param1,owner)
                                    a4.inviteIntoGroup(op.param1,owner)
                                except:
                                    try:
                                        a5.kickoutFromGroup(op.param1,[op.param2])
                                        a5.findAndAddContactsByMid(op.param1,owner)
                                        a5.inviteIntoGroup(op.param1,owner)
                                    except:
                                        try:
                                            a5.kickoutFromGroup(op.param1,[op.param2])
                                            a5.findAndAddContactsByMid(op.param1,owner)
                                            a5.inviteIntoGroup(op.param1,owner)
                                        except:
                                            pass

                return

            if admin in op.param3:
                if op.param2 in Bots:
                    pass
                if op.param2 in owner:
                    pass
                if op.param2 in admin:
                    pass
                if op.param2 in staff:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    try:
                        a1.kickoutFromGroup(op.param1,[op.param2])
                        a1.findAndAddContactsByMid(op.param1,admin)
                        a1.inviteIntoGroup(op.param1,admin)
                    except:
                        try:
                            a2.kickoutFromGroup(op.param1,[op.param2])
                            a2.findAndAddContactsByMid(op.param1,admin)
                            a2.inviteIntoGroup(op.param1,admin)
                        except:
                            try:
                                a3.kickoutFromGroup(op.param1,[op.param2])
                                a3.findAndAddContactsByMid(op.param1,admin)
                                a3.inviteIntoGroup(op.param1,admin)
                            except:
                                try:
                                    a4.kickoutFromGroup(op.param1,[op.param2])
                                    a4.findAndAddContactsByMid(op.param1,admin)
                                    a4.inviteIntoGroup(op.param1,admin)
                                except:
                                    try:
                                        a5.kickoutFromGroup(op.param1,[op.param2])
                                        a5.findAndAddContactsByMid(op.param1,admin)
                                        a5.inviteIntoGroup(op.param1,admin)
                                    except:
                                        try:
                                            a5.kickoutFromGroup(op.param1,[op.param2])
                                            a5.findAndAddContactsByMid(op.param1,admin)
                                            a5.inviteIntoGroup(op.param1,admin)
                                        except:
                                            pass

                return

            if staff in op.param3:
                if op.param2 in Bots:
                    pass
                if op.param2 in owner:
                    pass
                if op.param2 in admin:
                    pass
                if op.param2 in staff:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    try:
                        a1.kickoutFromGroup(op.param1,[op.param2])
                        a1.findAndAddContactsByMid(op.param1,staff)
                        a1.inviteIntoGroup(op.param1,staff)
                    except:
                        try:
                            a2.kickoutFromGroup(op.param1,[op.param2])
                            a2.findAndAddContactsByMid(op.param1,staff)
                            a2.inviteIntoGroup(op.param1,staff)
                        except:
                            try:
                                a3.kickoutFromGroup(op.param1,[op.param2])
                                a3.findAndAddContactsByMid(op.param1,staff)
                                a3.inviteIntoGroup(op.param1,staff)
                            except:
                                try:
                                    a4.kickoutFromGroup(op.param1,[op.param2])
                                    a4.findAndAddContactsByMid(op.param1,staff)
                                    a4.inviteIntoGroup(op.param1,staff)
                                except:
                                    try:
                                        a5.kickoutFromGroup(op.param1,[op.param2])
                                        a5.findAndAddContactsByMid(op.param1,staff)
                                        a5.inviteIntoGroup(op.param1,staff)
                                    except:
                                        try:
                                            a5.kickoutFromGroup(op.param1,[op.param2])
                                            a5.findAndAddContactsByMid(op.param1,staff)
                                            a5.inviteIntoGroup(op.param1,staff)
                                        except:
                                            pass

                return
#===============================================================================
        if op.type == 32:
            if Amid in op.param3:
                if op.param2 in Bots:
                    pass
                if op.param2 in owner:
                    pass
                if op.param2 in admin:
                    pass
                if op.param2 in staff:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    try:
                        a2.kickoutFromGroup(op.param1,[op.param2])
                        a2.findAndAddContactsByMid(op.param3)
                        a2.inviteIntoGroup(op.param1,[Amid,Cmid,Dmid,Emid,Emid])
                        a1.acceptGroupInvitation(op.param1)
                        a3.acceptGroupInvitation(op.param1)
                        a4.acceptGroupInvitation(op.param1)
                        a5.acceptGroupInvitation(op.param1)
                        a5.acceptGroupInvitation(op.param1)
                        group = a1.getGroup(op.param1)
                        nama = [contact.mid for contact in group.members]
                        for x in nama:
                            if x in wait["blacklist"]:
                                a1.kickoutFromGroup(op.param1,[x])
                    except:
                        try:
                            a3.kickoutFromGroup(op.param1,[op.param2])
                            a3.findAndAddContactsByMid(op.param3)
                            a3.inviteIntoGroup(op.param1,[Amid,Bmid,Dmid,Emid,Emid])
                            a1.acceptGroupInvitation(op.param1)
                            a2.acceptGroupInvitation(op.param1)
                            a4.acceptGroupInvitation(op.param1)
                            a5.acceptGroupInvitation(op.param1)
                            a5.acceptGroupInvitation(op.param1)
                            group = a1.getGroup(op.param1)
                            nama = [contact.mid for contact in group.members]
                            for x in nama:
                                if x in wait["blacklist"]:
                                    a1.kickoutFromGroup(op.param1,[x])
                        except:
                            try:
                                a4.kickoutFromGroup(op.param1,[op.param2])
                                a4.findAndAddContactsByMid(op.param3)
                                a4.inviteIntoGroup(op.param1,[Amid,Bmid,Cmid,Emid,Emid])
                                a1.acceptGroupInvitation(op.param1)
                                a2.acceptGroupInvitation(op.param1)
                                a3.acceptGroupInvitation(op.param1)
                                a5.acceptGroupInvitation(op.param1)
                                a5.acceptGroupInvitation(op.param1)
                                group = a1.getGroup(op.param1)
                                nama = [contact.mid for contact in group.members]
                                for x in nama:
                                    if x in wait["blacklist"]:
                                        a1.kickoutFromGroup(op.param1,[x])
                            except:
                                try:
                                    a5.kickoutFromGroup(op.param1,[op.param2])
                                    a5.findAndAddContactsByMid(op.param3)
                                    a5.inviteIntoGroup(op.param1,[Amid,Bmid,Cmid,Dmid,Emid])
                                    a1.acceptGroupInvitation(op.param1)
                                    a2.acceptGroupInvitation(op.param1)
                                    a3.acceptGroupInvitation(op.param1)
                                    a4.acceptGroupInvitation(op.param1)
                                    a5.acceptGroupInvitation(op.param1)
                                    group = a1.getGroup(op.param1)
                                    nama = [contact.mid for contact in group.members]
                                    for x in nama:
                                        if x in wait["blacklist"]:
                                            a1.kickoutFromGroup(op.param1,[x])
                                except:
                                    try:
                                        a5.kickoutFromGroup(op.param1,[op.param2])
                                        a5.findAndAddContactsByMid(op.param3)
                                        a5.inviteIntoGroup(op.param1,[Amid,Bmid,Cmid,Dmid,Emid])
                                        a1.acceptGroupInvitation(op.param1)
                                        a2.acceptGroupInvitation(op.param1)
                                        a3.acceptGroupInvitation(op.param1)
                                        a4.acceptGroupInvitation(op.param1)
                                        a5.acceptGroupInvitation(op.param1)
                                        group = a1.getGroup(op.param1)
                                        nama = [contact.mid for contact in group.members]
                                        for x in nama:
                                            if x in wait["blacklist"]:
                                                a1.kickoutFromGroup(op.param1,[x])
                                    except:
                                        pass

                return

            if Bmid in op.param3:
                if op.param2 in Bots:
                    pass
                if op.param2 in owner:
                    pass
                if op.param2 in admin:
                    pass
                if op.param2 in staff:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    try:
                        a3.kickoutFromGroup(op.param1,[op.param2])
                        a3.findAndAddContactsByMid(op.param3)
                        a3.inviteIntoGroup(op.param1,[Bmid,Dmid,Emid,Emid,Amid])
                        a2.acceptGroupInvitation(op.param1)
                        a1.acceptGroupInvitation(op.param1)
                        a4.acceptGroupInvitation(op.param1)
                        a5.acceptGroupInvitation(op.param1)
                        a5.acceptGroupInvitation(op.param1)
                        group = a2.getGroup(op.param1)
                        nama = [contact.mid for contact in group.members]
                        for x in nama:
                            if x in wait["blacklist"]:
                                a2.kickoutFromGroup(op.param1,[x])
                    except:
                        try:
                            a4.kickoutFromGroup(op.param1,[op.param2])
                            a4.findAndAddContactsByMid(op.param3)
                            a4.inviteIntoGroup(op.param1,[Bmid,Cmid,Emid,Emid,Amid])
                            a2.acceptGroupInvitation(op.param1)
                            a1.acceptGroupInvitation(op.param1)
                            a3.acceptGroupInvitation(op.param1)
                            a5.acceptGroupInvitation(op.param1)
                            a5.acceptGroupInvitation(op.param1)
                            group = a2.getGroup(op.param1)
                            nama = [contact.mid for contact in group.members]
                            for x in nama:
                                if x in wait["blacklist"]:
                                    a2.kickoutFromGroup(op.param1,[x])
                        except:
                            try:
                                a5.kickoutFromGroup(op.param1,[op.param2])
                                a5.findAndAddContactsByMid(op.param3)
                                a5.inviteIntoGroup(op.param1,[Bmid,Cmid,Dmid,Emid,Amid])
                                a2.acceptGroupInvitation(op.param1)
                                a1.acceptGroupInvitation(op.param1)
                                a3.acceptGroupInvitation(op.param1)
                                a4.acceptGroupInvitation(op.param1)
                                a5.acceptGroupInvitation(op.param1)
                                group = a2.getGroup(op.param1)
                                nama = [contact.mid for contact in group.members]
                                for x in nama:
                                    if x in wait["blacklist"]:
                                        a2.kickoutFromGroup(op.param1,[x])
                            except:
                                try:
                                    a5.kickoutFromGroup(op.param1,[op.param2])
                                    a5.findAndAddContactsByMid(op.param3)
                                    a5.inviteIntoGroup(op.param1,[Bmid,Cmid,Dmid,Emid,Amid])
                                    a2.acceptGroupInvitation(op.param1)
                                    a1.acceptGroupInvitation(op.param1)
                                    a3.acceptGroupInvitation(op.param1)
                                    a4.acceptGroupInvitation(op.param1)
                                    a5.acceptGroupInvitation(op.param1)
                                    group = a2.getGroup(op.param1)
                                    nama = [contact.mid for contact in group.members]
                                    for x in nama:
                                        if x in wait["blacklist"]:
                                            a2.kickoutFromGroup(op.param1,[x])
                                except:
                                    try:
                                        a1.kickoutFromGroup(op.param1,[op.param2])
                                        a1.findAndAddContactsByMid(op.param3)
                                        a1.inviteIntoGroup(op.param1,[Bmid,Cmid,Dmid,Emid,Emid])
                                        a2.acceptGroupInvitation(op.param1)
                                        a3.acceptGroupInvitation(op.param1)
                                        a4.acceptGroupInvitation(op.param1)
                                        a5.acceptGroupInvitation(op.param1)
                                        a5.acceptGroupInvitation(op.param1)
                                        group = a2.getGroup(op.param1)
                                        nama = [contact.mid for contact in group.members]
                                        for x in nama:
                                            if x in wait["blacklist"]:
                                                a2.kickoutFromGroup(op.param1,[x])
                                    except:
                                        pass

                return

            if Cmid in op.param3:
                if op.param2 in Bots:
                    pass
                if op.param2 in owner:
                    pass
                if op.param2 in admin:
                    pass
                if op.param2 in staff:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    try:
                        a4.kickoutFromGroup(op.param1,[op.param2])
                        a4.findAndAddContactsByMid(op.param3)
                        a4.inviteIntoGroup(op.param1,[Cmid,Emid,Emid,Amid,Bmid])
                        a3.acceptGroupInvitation(op.param1)
                        a1.acceptGroupInvitation(op.param1)
                        a2.acceptGroupInvitation(op.param1)
                        a5.acceptGroupInvitation(op.param1)
                        a5.acceptGroupInvitation(op.param1)
                        group = a3.getGroup(op.param1)
                        nama = [contact.mid for contact in group.members]
                        for x in nama:
                            if x in wait["blacklist"]:
                                a3.kickoutFromGroup(op.param1,[x])
                    except:
                        try:
                            a5.kickoutFromGroup(op.param1,[op.param2])
                            a5.findAndAddContactsByMid(op.param3)
                            a5.inviteIntoGroup(op.param1,[Cmid,Dmid,Emid,Amid,Bmid])
                            a3.acceptGroupInvitation(op.param1)
                            a1.acceptGroupInvitation(op.param1)
                            a2.acceptGroupInvitation(op.param1)
                            a4.acceptGroupInvitation(op.param1)
                            a5.acceptGroupInvitation(op.param1)
                            group = a3.getGroup(op.param1)
                            nama = [contact.mid for contact in group.members]
                            for x in nama:
                                if x in wait["blacklist"]:
                                    a3.kickoutFromGroup(op.param1,[x])
                        except:
                            try:
                                a5.kickoutFromGroup(op.param1,[op.param2])
                                a5.findAndAddContactsByMid(op.param3)
                                a5.inviteIntoGroup(op.param1,[Cmid,Dmid,Emid,Amid,Bmid])
                                a3.acceptGroupInvitation(op.param1)
                                a1.acceptGroupInvitation(op.param1)
                                a2.acceptGroupInvitation(op.param1)
                                a4.acceptGroupInvitation(op.param1)
                                a5.acceptGroupInvitation(op.param1)
                                group = a3.getGroup(op.param1)
                                nama = [contact.mid for contact in group.members]
                                for x in nama:
                                    if x in wait["blacklist"]:
                                        a3.kickoutFromGroup(op.param1,[x])
                            except:
                                try:
                                    a1.kickoutFromGroup(op.param1,[op.param2])
                                    a1.findAndAddContactsByMid(op.param3)
                                    a1.inviteIntoGroup(op.param1,[Cmid,Dmid,Emid,Emid,Bmid])
                                    a3.acceptGroupInvitation(op.param1)
                                    a2.acceptGroupInvitation(op.param1)
                                    a4.acceptGroupInvitation(op.param1)
                                    a5.acceptGroupInvitation(op.param1)
                                    a5.acceptGroupInvitation(op.param1)
                                    group = a3.getGroup(op.param1)
                                    nama = [contact.mid for contact in group.members]
                                    for x in nama:
                                        if x in wait["blacklist"]:
                                            a3.kickoutFromGroup(op.param1,[x])
                                except:
                                    try:
                                        a2.kickoutFromGroup(op.param1,[op.param2])
                                        a2.findAndAddContactsByMid(op.param3)
                                        a2.inviteIntoGroup(op.param1,[Cmid,Dmid,Emid,Amid,Emid])
                                        a3.acceptGroupInvitation(op.param1)
                                        a1.acceptGroupInvitation(op.param1)
                                        a4.acceptGroupInvitation(op.param1)
                                        a5.acceptGroupInvitation(op.param1)
                                        a5.acceptGroupInvitation(op.param1)
                                        group = a3.getGroup(op.param1)
                                        nama = [contact.mid for contact in group.members]
                                        for x in nama:
                                            if x in wait["blacklist"]:
                                                a3.kickoutFromGroup(op.param1,[x])
                                    except:
                                        pass

                return

            if Dmid in op.param3:
                if op.param2 in Bots:
                    pass
                if op.param2 in owner:
                    pass
                if op.param2 in admin:
                    pass
                if op.param2 in staff:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    try:
                        a5.kickoutFromGroup(op.param1,[op.param2])
                        a5.findAndAddContactsByMid(op.param3)
                        a5.inviteIntoGroup(op.param1,[Dmid,Emid,Amid,Bmid,Cmid])
                        a4.acceptGroupInvitation(op.param1)
                        a1.acceptGroupInvitation(op.param1)
                        a2.acceptGroupInvitation(op.param1)
                        a3.acceptGroupInvitation(op.param1)
                        a5.acceptGroupInvitation(op.param1)
                        group = a4.getGroup(op.param1)
                        nama = [contact.mid for contact in group.members]
                        for x in nama:
                            if x in wait["blacklist"]:
                                a4.kickoutFromGroup(op.param1,[x])
                    except:
                        try:
                            a5.kickoutFromGroup(op.param1,[op.param2])
                            a5.findAndAddContactsByMid(op.param3)
                            a5.inviteIntoGroup(op.param1,[Dmid,Emid,Emid,Amid,Cmid])
                            a4.acceptGroupInvitation(op.param1)
                            a1.acceptGroupInvitation(op.param1)
                            a2.acceptGroupInvitation(op.param1)
                            a3.acceptGroupInvitation(op.param1)
                            a5.acceptGroupInvitation(op.param1)
                            group = a4.getGroup(op.param1)
                            nama = [contact.mid for contact in group.members]
                            for x in nama:
                                if x in wait["blacklist"]:
                                    a4.kickoutFromGroup(op.param1,[x])
                        except:
                            try:
                                a1.kickoutFromGroup(op.param1,[op.param2])
                                a1.findAndAddContactsByMid(op.param3)
                                a1.inviteIntoGroup(op.param1,[Dmid,Emid,Emid,Bmid,Cmid])
                                a4.acceptGroupInvitation(op.param1)
                                a2.acceptGroupInvitation(op.param1)
                                a3.acceptGroupInvitation(op.param1)
                                a5.acceptGroupInvitation(op.param1)
                                a5.acceptGroupInvitation(op.param1)
                                group = a4.getGroup(op.param1)
                                nama = [contact.mid for contact in group.members]
                                for x in nama:
                                    if x in wait["blacklist"]:
                                        a4.kickoutFromGroup(op.param1,[x])
                            except:
                                try:
                                    a2.kickoutFromGroup(op.param1,[op.param2])
                                    a2.findAndAddContactsByMid(op.param3)
                                    a2.inviteIntoGroup(op.param1,[Dmid,Emid,Emid,Amid,Cmid])
                                    a4.acceptGroupInvitation(op.param1)
                                    a1.acceptGroupInvitation(op.param1)
                                    a3.acceptGroupInvitation(op.param1)
                                    a5.acceptGroupInvitation(op.param1)
                                    a5.acceptGroupInvitation(op.param1)
                                    group = a4.getGroup(op.param1)
                                    nama = [contact.mid for contact in group.members]
                                    for x in nama:
                                        if x in wait["blacklist"]:
                                            a4.kickoutFromGroup(op.param1,[x])
                                except:
                                    try:
                                        a3.kickoutFromGroup(op.param1,[op.param2])
                                        a3.findAndAddContactsByMid(op.param3)
                                        a3.inviteIntoGroup(op.param1,[Dmid,Emid,Emid,Amid,Bmid])
                                        a4.acceptGroupInvitation(op.param1)
                                        a1.acceptGroupInvitation(op.param1)
                                        a2.acceptGroupInvitation(op.param1)
                                        a5.acceptGroupInvitation(op.param1)
                                        a5.acceptGroupInvitation(op.param1)
                                        group = a4.getGroup(op.param1)
                                        nama = [contact.mid for contact in group.members]
                                        for x in nama:
                                            if x in wait["blacklist"]:
                                                a4.kickoutFromGroup(op.param1,[x])
                                    except:
                                        pass

                return

            if Emid in op.param3:
                if op.param2 in Bots:
                    pass
                if op.param2 in owner:
                    pass
                if op.param2 in admin:
                    pass
                if op.param2 in staff:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    try:
                        a5.kickoutFromGroup(op.param1,[op.param2])
                        a5.findAndAddContactsByMid(op.param3)
                        a5.inviteIntoGroup(op.param1,[Emid,Amid,Bmid,Cmid,Dmid])
                        a5.acceptGroupInvitation(op.param1)
                        a1.acceptGroupInvitation(op.param1)
                        a2.acceptGroupInvitation(op.param1)
                        a3.acceptGroupInvitation(op.param1)
                        a4.acceptGroupInvitation(op.param1)
                        group = a5.getGroup(op.param1)
                        nama = [contact.mid for contact in group.members]
                        for x in nama:
                            if x in wait["blacklist"]:
                                a5.kickoutFromGroup(op.param1,[x])
                    except:
                        try:
                            a1.kickoutFromGroup(op.param1,[op.param2])
                            a1.findAndAddContactsByMid(op.param3)
                            a1.inviteIntoGroup(op.param1,[Emid,Emid,Bmid,Cmid,Dmid])
                            a5.acceptGroupInvitation(op.param1)
                            a2.acceptGroupInvitation(op.param1)
                            a3.acceptGroupInvitation(op.param1)
                            a4.acceptGroupInvitation(op.param1)
                            a5.acceptGroupInvitation(op.param1)
                            group = a5.getGroup(op.param1)
                            nama = [contact.mid for contact in group.members]
                            for x in nama:
                                if x in wait["blacklist"]:
                                    a5.kickoutFromGroup(op.param1,[x])
                        except:
                            try:
                                a2.kickoutFromGroup(op.param1,[op.param2])
                                a2.findAndAddContactsByMid(op.param3)
                                a2.inviteIntoGroup(op.param1,[Emid,Emid,Cmid,Amid,Dmid])
                                a5.acceptGroupInvitation(op.param1)
                                a1.acceptGroupInvitation(op.param1)
                                a3.acceptGroupInvitation(op.param1)
                                a4.acceptGroupInvitation(op.param1)
                                a5.acceptGroupInvitation(op.param1)
                                group = a5.getGroup(op.param1)
                                nama = [contact.mid for contact in group.members]
                                for x in nama:
                                    if x in wait["blacklist"]:
                                        a5.kickoutFromGroup(op.param1,[x])
                            except:
                                try:
                                    a3.kickoutFromGroup(op.param1,[op.param2])
                                    a3.findAndAddContactsByMid(op.param3)
                                    a3.inviteIntoGroup(op.param1,[Emid,Emid,Bmid,Amid,Dmid])
                                    a5.acceptGroupInvitation(op.param1)
                                    a1.acceptGroupInvitation(op.param1)
                                    a2.acceptGroupInvitation(op.param1)
                                    a4.acceptGroupInvitation(op.param1)
                                    a5.acceptGroupInvitation(op.param1)
                                    group = a5.getGroup(op.param1)
                                    nama = [contact.mid for contact in group.members]
                                    for x in nama:
                                        if x in wait["blacklist"]:
                                            a5.kickoutFromGroup(op.param1,[x])
                                except:
                                    try:
                                        a4.kickoutFromGroup(op.param1,[op.param2])
                                        a4.findAndAddContactsByMid(op.param3)
                                        a4.inviteIntoGroup(op.param1,[Emid,Emid,Cmid,Amid,Bmid])
                                        a5.acceptGroupInvitation(op.param1)
                                        a1.acceptGroupInvitation(op.param1)
                                        a2.acceptGroupInvitation(op.param1)
                                        a3.acceptGroupInvitation(op.param1)
                                        a5.acceptGroupInvitation(op.param1)
                                        group = a5.getGroup(op.param1)
                                        nama = [contact.mid for contact in group.members]
                                        for x in nama:
                                            if x in wait["blacklist"]:
                                                a5.kickoutFromGroup(op.param1,[x])
                                    except:
                                        pass

                return

            if Emid in op.param3:
                if op.param2 in Bots:
                    pass
                if op.param2 in owner:
                    pass
                if op.param2 in admin:
                    pass
                if op.param2 in staff:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    try:
                        a1.kickoutFromGroup(op.param1,[op.param2])
                        a1.findAndAddContactsByMid(op.param3)
                        a1.inviteIntoGroup(op.param1,[Emid,Bmid,Cmid,Dmid,Emid])
                        a5.acceptGroupInvitation(op.param1)
                        a2.acceptGroupInvitation(op.param1)
                        a3.acceptGroupInvitation(op.param1)
                        a4.acceptGroupInvitation(op.param1)
                        a5.acceptGroupInvitation(op.param1)
                        group = a5.getGroup(op.param1)
                        nama = [contact.mid for contact in group.members]
                        for x in nama:
                            if x in wait["blacklist"]:
                                a5.kickoutFromGroup(op.param1,[x])
                    except:
                        try:
                            a2.kickoutFromGroup(op.param1,[op.param2])
                            a2.findAndAddContactsByMid(op.param3)
                            a2.inviteIntoGroup(op.param1,[Emid,Amid,Cmid,Dmid,Emid])
                            a5.acceptGroupInvitation(op.param1)
                            a1.acceptGroupInvitation(op.param1)
                            a3.acceptGroupInvitation(op.param1)
                            a4.acceptGroupInvitation(op.param1)
                            a5.acceptGroupInvitation(op.param1)
                            group = a5.getGroup(op.param1)
                            nama = [contact.mid for contact in group.members]
                            for x in nama:
                                if x in wait["blacklist"]:
                                    a5.kickoutFromGroup(op.param1,[x])
                        except:
                            try:
                                a3.kickoutFromGroup(op.param1,[op.param2])
                                a3.findAndAddContactsByMid(op.param3)
                                a3.inviteIntoGroup(op.param1,[Emid,Bmid,Amid,Dmid,Emid])
                                a5.acceptGroupInvitation(op.param1)
                                a1.acceptGroupInvitation(op.param1)
                                a2.acceptGroupInvitation(op.param1)
                                a4.acceptGroupInvitation(op.param1)
                                a5.acceptGroupInvitation(op.param1)
                                group = a5.getGroup(op.param1)
                                nama = [contact.mid for contact in group.members]
                                for x in nama:
                                    if x in wait["blacklist"]:
                                        a5.kickoutFromGroup(op.param1,[x])
                            except:
                                try:
                                    a4.kickoutFromGroup(op.param1,[op.param2])
                                    a4.findAndAddContactsByMid(op.param3)
                                    a4.inviteIntoGroup(op.param1,[Emid,Bmid,Cmid,Amid,Emid])
                                    a5.acceptGroupInvitation(op.param1)
                                    a1.acceptGroupInvitation(op.param1)
                                    a2.acceptGroupInvitation(op.param1)
                                    a3.acceptGroupInvitation(op.param1)
                                    a5.acceptGroupInvitation(op.param1)
                                    group = a5.getGroup(op.param1)
                                    nama = [contact.mid for contact in group.members]
                                    for x in nama:
                                        if x in wait["blacklist"]:
                                            a5.kickoutFromGroup(op.param1,[x])
                                except:
                                    try:
                                        a5.kickoutFromGroup(op.param1,[op.param2])
                                        a5.findAndAddContactsByMid(op.param3)
                                        a5.inviteIntoGroup(op.param1,[Emid,Bmid,Cmid,Dmid,Amid])
                                        a5.acceptGroupInvitation(op.param1)
                                        a1.acceptGroupInvitation(op.param1)
                                        a2.acceptGroupInvitation(op.param1)
                                        a3.acceptGroupInvitation(op.param1)
                                        a4.acceptGroupInvitation(op.param1)
                                        group = a5.getGroup(op.param1)
                                        nama = [contact.mid for contact in group.members]
                                        for x in nama:
                                            if x in wait["blacklist"]:
                                                a5.kickoutFromGroup(op.param1,[x])
                                    except:
                                        pass
                return

            if mid in op.param3:
                if op.param2 in Bots:
                    pass
                if op.param2 in owner:
                    pass
                if op.param2 in admin:
                    pass
                if op.param2 in staff:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    try:
                        a1.kickoutFromGroup(op.param1,[op.param2])
                        a1.findAndAddContactsByMid(op.param3)
                        a1.inviteIntoGroup(op.param1,[Bmid,Cmid,Dmid,Emid,Emid])
                        ais.acceptGroupInvitation(op.param1)
                    except:
                        try:
                            a2.kickoutFromGroup(op.param1,[op.param2])
                            a2.findAndAddContactsByMid(op.param3)
                            a2.inviteIntoGroup(op.param1,[Cmid,Dmid,Emid,Emid,Amid])
                            ais.acceptGroupInvitation(op.param1)
                        except:
                            try:
                                a3.kickoutFromGroup(op.param1,[op.param2])
                                a3.findAndAddContactsByMid(op.param3)
                                a3.inviteIntoGroup(op.param1,[Bmid,Amid,Dmid,Emid,Emid])
                                ais.acceptGroupInvitation(op.param1)
                            except:
                                try:
                                    a4.kickoutFromGroup(op.param1,[op.param2])
                                    a4.findAndAddContactsByMid(op.param3)
                                    a4.inviteIntoGroup(op.param1,[Bmid,Cmid,Amid,Emid,Emid])
                                    ais.acceptGroupInvitation(op.param1)
                                except:
                                    try:
                                        a5.kickoutFromGroup(op.param1,[op.param2])
                                        a5.findAndAddContactsByMid(op.param3)
                                        a5.inviteIntoGroup(op.param1,[Bmid,Cmid,Dmid,Amid,Emid])
                                        ais.acceptGroupInvitation(op.param1)
                                    except:
                                        try:
                                            a5.kickoutFromGroup(op.param1,[op.param2])
                                            a5.findAndAddContactsByMid(op.param3)
                                            a5.inviteIntoGroup(op.param1,[Bmid,Cmid,Dmid,Emid,Amid])
                                            ais.acceptGroupInvitation(op.param1)
                                        except:
                                            pass

                return

            if owner in op.param3:
                if op.param2 in Bots:
                    pass
                if op.param2 in owner:
                    pass
                if op.param2 in admin:
                    pass
                if op.param2 in staff:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    try:
                        a1.kickoutFromGroup(op.param1,[op.param2])
                        a1.findAndAddContactsByMid(op.param1,owner)
                        a1.inviteIntoGroup(op.param1,owner)
                    except:
                        try:
                            a2.kickoutFromGroup(op.param1,[op.param2])
                            a2.findAndAddContactsByMid(op.param1,owner)
                            a2.inviteIntoGroup(op.param1,owner)
                        except:
                            try:
                                a3.kickoutFromGroup(op.param1,[op.param2])
                                a3.findAndAddContactsByMid(op.param1,owner)
                                a3.inviteIntoGroup(op.param1,owner)
                            except:
                                try:
                                    a4.kickoutFromGroup(op.param1,[op.param2])
                                    a4.findAndAddContactsByMid(op.param1,owner)
                                    a4.inviteIntoGroup(op.param1,owner)
                                except:
                                    try:
                                        a5.kickoutFromGroup(op.param1,[op.param2])
                                        a5.findAndAddContactsByMid(op.param1,owner)
                                        a5.inviteIntoGroup(op.param1,owner)
                                    except:
                                        try:
                                            a5.kickoutFromGroup(op.param1,[op.param2])
                                            a5.findAndAddContactsByMid(op.param1,owner)
                                            a5.inviteIntoGroup(op.param1,owner)
                                        except:
                                            pass

                return

            if admin in op.param3:
                if op.param2 in Bots:
                    pass
                if op.param2 in owner:
                    pass
                if op.param2 in admin:
                    pass
                if op.param2 in staff:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    try:
                        a1.kickoutFromGroup(op.param1,[op.param2])
                        a1.findAndAddContactsByMid(op.param1,admin)
                        a1.inviteIntoGroup(op.param1,admin)
                    except:
                        try:
                            a2.kickoutFromGroup(op.param1,[op.param2])
                            a2.findAndAddContactsByMid(op.param1,admin)
                            a2.inviteIntoGroup(op.param1,admin)
                        except:
                            try:
                                a3.kickoutFromGroup(op.param1,[op.param2])
                                a3.findAndAddContactsByMid(op.param1,admin)
                                a3.inviteIntoGroup(op.param1,admin)
                            except:
                                try:
                                    a4.kickoutFromGroup(op.param1,[op.param2])
                                    a4.findAndAddContactsByMid(op.param1,admin)
                                    a4.inviteIntoGroup(op.param1,admin)
                                except:
                                    try:
                                        a5.kickoutFromGroup(op.param1,[op.param2])
                                        a5.findAndAddContactsByMid(op.param1,admin)
                                        a5.inviteIntoGroup(op.param1,admin)
                                    except:
                                        try:
                                            a5.kickoutFromGroup(op.param1,[op.param2])
                                            a5.findAndAddContactsByMid(op.param1,admin)
                                            a5.inviteIntoGroup(op.param1,admin)
                                        except:
                                            pass

                return

            if staff in op.param3:
                if op.param2 in Bots:
                    pass
                if op.param2 in owner:
                    pass
                if op.param2 in admin:
                    pass
                if op.param2 in staff:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    try:
                        a1.kickoutFromGroup(op.param1,[op.param2])
                        a1.findAndAddContactsByMid(op.param1,staff)
                        a1.inviteIntoGroup(op.param1,staff)
                    except:
                        try:
                            a2.kickoutFromGroup(op.param1,[op.param2])
                            a2.findAndAddContactsByMid(op.param1,staff)
                            a2.inviteIntoGroup(op.param1,staff)
                        except:
                            try:
                                a3.kickoutFromGroup(op.param1,[op.param2])
                                a3.findAndAddContactsByMid(op.param1,staff)
                                a3.inviteIntoGroup(op.param1,staff)
                            except:
                                try:
                                    a4.kickoutFromGroup(op.param1,[op.param2])
                                    a4.findAndAddContactsByMid(op.param1,staff)
                                    a4.inviteIntoGroup(op.param1,staff)
                                except:
                                    try:
                                        a5.kickoutFromGroup(op.param1,[op.param2])
                                        a5.findAndAddContactsByMid(op.param1,staff)
                                        a5.inviteIntoGroup(op.param1,staff)
                                    except:
                                        try:
                                            a5.kickoutFromGroup(op.param1,[op.param2])
                                            a5.findAndAddContactsByMid(op.param1,staff)
                                            a5.inviteIntoGroup(op.param1,staff)
                                        except:
                                            pass
                      
                return
        if op.type == 32: 
            if op.param2 in wait["blacklist"]:
                try:
                    random.choice(ABC).kickoutFromGroup(op.param1,[op.param2])                   
                    print ("BLACKLIST KICK 32")
                except:
                    pass

                return

        if op.type == 55:
            try:
                if op.param1 in Setmain["SCreadPoint"]:
                   if op.param2 in Setmain["SCreadMember"][op.param1]:
                       pass
                   else:
                       Setmain["SCreadMember"][op.param1][op.param2] = True
                else:
                   pass
            except:
                pass

        if op.type == 55:
            if op.param2 in wait["blacklist"]:
                ais.kickoutFromGroup(op.param1,[op.param2])
                print ("BLACKLIST KICK 55")
            else:
                pass

            if cctv['cyduk'][op.param1]==True:
                if op.param1 in cctv['point']:
                    Name = ais.getContact(op.param2).displayName
                    if Name in cctv['sidermem'][op.param1]:
                        pass
                    else:
                        cctv['sidermem'][op.param1] += "\n~ " + Name
                        siderMembers(op.param1, [op.param2])
                        contact = ais.getContact(op.param2)
                        image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                        ais.sendImageWithURL(op.param1, image)                        

        if op.type == 65:
            if wait["unsend"] == True:
                try:
                    at = op.param1
                    msg_id = op.param2
                    if msg_id in msg_dict:
                        if msg_dict[msg_id]["from"]:
                           if msg_dict[msg_id]["text"] == 'Gambarnya dibawah':
                                ginfo = ais.getGroup(at)
                                aische = ais.getContact(msg_dict[msg_id]["from"])
                                zx = ""
                                zxc = ""
                                zx2 = []
                                xpesan =  "「 Gambar Dihapus 」\n• Pengirim : "
                                ret_ = "• Nama Grup : {}".format(str(ginfo.name))
                                ret_ += "\n• Waktu Ngirim : {}".format(dt_to_str(cTime_to_datetime(msg_dict[msg_id]["createdTime"])))
                                ry = str(ais.displayName)
                                pesan = ''
                                pesan2 = pesan+"@x \n"
                                xlen = str(len(zxc)+len(xpesan))
                                xlen2 = str(len(zxc)+len(pesan2)+len(xpesan)-1)
                                zx = {'S':xlen, 'E':xlen2, 'M':ais.mid}
                                zx2.append(zx)
                                zxc += pesan2
                                text = xpesan + zxc + ret_ + ""
                                ais.sendMessage(at, text, contentMetadata={'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}, contentType=0)
                                ais.sendImage(at, msg_dict[msg_id]["data"])
                           else:
                                ginfo = ais.getGroup(at)
                                aische = ais.getContact(msg_dict[msg_id]["from"])
                                ret_ =  "✯͜͡❂➣ 「 Pesan Dihapus 」\n"
                                ret_ += "✯͜͡❂➣  Pengirim : {}".format(str(ais.displayName))
                                ret_ += "\n✯͜͡❂➣ Nama Grup : {}".format(str(ginfo.name))
                                ret_ += "\n✯͜͡❂➣ Waktu Ngirim : {}".format(dt_to_str(cTime_to_datetime(msg_dict[msg_id]["createdTime"])))
                                ret_ += "\n✯͜͡❂➣ Pesannya : {}".format(str(msg_dict[msg_id]["text"]))
                                ais.sendMessage(at, str(ret_))
                        del msg_dict[msg_id]
                except Exception as e:
                    print(e)

        if op.type == 65:
            if wait["unsend"] == True:
                try:
                    at = op.param1
                    msg_id = op.param2
                    if msg_id in msg_dict1:
                        if msg_dict1[msg_id]["from"]:
                                ginfo = ais.getGroup(at)
                                aische = ais.getContact(msg_dict1[msg_id]["from"])
                                ret_ =  "「 Sticker Dihapus 」\n"
                                ret_ += "• Pengirim : {}".format(str(ais.displayName))
                                ret_ += "\n• Nama Grup : {}".format(str(ginfo.name))
                                ret_ += "\n• Waktu Ngirim : {}".format(dt_to_str(cTime_to_datetime(msg_dict1[msg_id]["createdTime"])))
                                ret_ += "{}".format(str(msg_dict1[msg_id]["text"]))
                                ais.sendMessage(at, str(ret_))
                                ais.sendImage(at, msg_dict1[msg_id]["data"])
                        del msg_dict1[msg_id]
                except Exception as e:
                    print(e)

        if op.type == 25 or op.type == 26:
           if wait["selfbot"] == True:
               msg = op.message
               if msg._from not in Bots:
                 if wait["talkban"] == True:
                   if msg._from in wait["Talkblacklist"]:
                      try:
                          ais.kickoutFromGroup(msg.to, [msg._from])
                          print ("BLACKLIST KICK 25-26")
                      except:
                          pass
               if 'MENTION' in msg.contentMetadata.keys() != None:
                 if wait["detectMention"] == True:
                   contact = ais.getContact(msg._from)
                   image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                   name = re.findall(r'@(\w+)', msg.text)
                   mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                   mentionees = mention['MENTIONEES']
                   for mention in mentionees:
                        if mention ['M'] in Bots:
                           ais.sendMessage(msg.to, wait["Respontag"])
                           ais.sendImageWithURL(msg.to,image)
                           ais.sendMessage(msg.to, None, contentMetadata={"STKID":"94734116","STKPKGID":"4981191","STKVER":"1"}, contentType=7)
                           break
               if 'MENTION' in msg.contentMetadata.keys() != None:
                 if wait["Mentiongift"] == True:
                   name = re.findall(r'@(\w+)', msg.text)
                   mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                   mentionees = mention['MENTIONEES']
                   for mention in mentionees:
                        if mention ['M'] in Bots:
                           idth = ["a0768339-c2d3-4189-9653-2909e9bb6f58","ec4a14ea-7437-407b-aee7-96b1cbbc1b4b","f35bd31f-5ec7-4b2f-b659-92adf5e3d151","ba1d5150-3b5f-4768-9197-01a3f971aa34","2b4ccc45-7309-47fe-a006-1a1edb846ddb","168d03c3-dbc2-456f-b982-3d6f85f52af2","d4f09a5f-29df-48ac-bca6-a204121ea165","517174f2-1545-43b9-a28f-5777154045a6","762ecc71-7f71-4900-91c9-4b3f213d8b26","2df50b22-112d-4f21-b856-f88df2193f9e"]
                           plihth = random.choice(idth)
                           jenis = ["5","6","7","8"]
                           plihjenis = random.choice(jenis)
                           ais.sendMessage(msg.to, " ✯͜͡❂➣sukses send gift\ncek pm😛.")
                           ais.sendMessage(msg._from, None, contentMetadata={"PRDID":plihth,"PRDTYPE":"THEME","MSGTPL":plihjenis}, contentType=9)
                           break                       
               if 'MENTION' in msg.contentMetadata.keys() != None:
                 if wait["Mentionkick"] == True:
                   name = re.findall(r'@(\w+)', msg.text)
                   mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                   mentionees = mention['MENTIONEES']
                   for mention in mentionees:
                        if mention ['M'] in Bots:
                           ais.sendMessage(msg.to, "oit...")
                           ais.kickoutFromGroup(msg.to, [msg._from])
                           break
               if msg.contentType == 7:
                 if wait["sticker"] == True:
                    msg.contentType = 0
                    ais.sendMessage(msg.to,"「Cek ID Sticker」\n=  STKID : " + msg.contentMetadata["STKID"] + "\n✯͜͡❂➣  STKPKGID : " + msg.contentMetadata["STKPKGID"] + "\n✯͜͡❂➣  STKVER : " + msg.contentMetadata["STKVER"]+ "\n\n「Link Sticker」" + "\nline://shop/detail/" + msg.contentMetadata["STKPKGID"])
               if msg.contentType == 13:
                 if wait["contact"] == True:
                    msg.contentType = 0
                    ais.sendMessage(msg.to,msg.contentMetadata["mid"])
                    if 'displayName' in msg.contentMetadata:
                        contact = ais.getContact(msg.contentMetadata["mid"])
                        path = ais.getContact(msg.contentMetadata["mid"]).picturePath
                        image = 'http://dl.profile.line.naver.jp'+path
                        ais.sendMessage(msg.to,"✯͜͡❂➣  Nama : " + msg.contentMetadata["displayName"] + "\n✯͜͡❂➣  MID : " + msg.contentMetadata["mid"] + "\n✯͜͡❂➣  Status : " + contact.statusMessage + "\n✯͜͡❂➣  Picture URL : http://dl.profile.line-cdn.net/" + contact.pictureStatus)
                        ais.sendImageWithURL(msg.to, image)

        if op.type == 25 or op.type == 26:
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if msg.contentType == 0:
                msg_dict[msg.id] = {"text":msg.text,"from":msg._from,"createdTime":msg.createdTime}
                
            if msg.contentType == 1:
                    path = ais.downloadObjectMsg(msg_id)
                    msg_dict[msg.id] = {"text":'Gambarnya dibawah',"data":path,"from":msg._from,"createdTime":msg.createdTime}
            if msg.contentType == 7:
                   stk_id = msg.contentMetadata["STKID"]
                   stk_ver = msg.contentMetadata["STKVER"]
                   pkg_id = msg.contentMetadata["STKPKGID"]
                   ret_ = "\n\n「 Sticker Info 」"
                   ret_ += "\n• Sticker ID : {}".format(stk_id)
                   ret_ += "\n• Sticker Version : {}".format(stk_ver)
                   ret_ += "\n• Sticker Package : {}".format(pkg_id)
                   ret_ += "\n• Sticker Url : line://shop/detail/{}".format(pkg_id)
                   query = int(stk_id)
                   if type(query) == int:
                            data = 'https://stickershop.line-scdn.net/stickershop/v1/sticker/'+str(query)+'/ANDROID/sticker.png'
                            path = ais.downloadFileURL(data)
                            msg_dict1[msg.id] = {"text":str(ret_),"data":path,"from":msg._from,"createdTime":msg.createdTime}
                                                      
                            
            if msg.toType == 0 or msg.toType == 2:
               if msg.toType == 0:
                    to = receiver
               elif msg.toType == 2:
                    to = receiver
               if msg.contentType == 7:
                 if wait["sticker"] == True:
                    msg.contentType = 0
                    ais.sendMessage(msg.to,"Cek ID Sticker\n\nSTKID : " + msg.contentMetadata["STKID"] + "\nSTKPKGID : " + msg.contentMetadata["STKPKGID"] + "\nSTKVER : " + msg.contentMetadata["STKVER"]+ "\n\n「Link Sticker」" + "\nline://shop/detail/" + msg.contentMetadata["STKPKGID"])
               if msg.contentType == 13:
                 if wait["contact"] == True:
                    msg.contentType = 0
                    ais.sendMessage(msg.to,msg.contentMetadata["mid"])
                    if 'displayName' in msg.contentMetadata:
                        contact = ais.getContact(msg.contentMetadata["mid"])
                        path = ais.getContact(msg.contentMetadata["mid"]).picturePath
                        image = 'http://dl.profile.line.naver.jp'+path
                        ais.sendMessage(msg.to,"Nama : " + msg.contentMetadata["displayName"] + "\nMID : " + msg.contentMetadata["mid"] + "\nStatus Msg : " + contact.statusMessage + "\nPicture URL : http://dl.profile.line-cdn.net/" + contact.pictureStatus)
                        ais.sendImageWithURL(msg.to, image)

               if msg.contentType == 13:
                 if msg._from in admin:
                  if wait["addbots"] == True:
                    if msg.contentMetadata["mid"] in Bots:
                        ais.sendMessage(msg.to,"Contact itu sudah jadi anggota BOTS")
                        wait["addbots"] = True
                    else:
                        Bots.append(msg.contentMetadata["mid"])
                        wait["addbots"] = True
                        ais.sendMessage(msg.to,"Berhasil menambahkan ke anggota BOTS")
                 if wait["dellbots"] == True:
                    if msg.contentMetadata["mid"] in Bots:
                        Bots.remove(msg.contentMetadata["mid"])
                        ais.sendMessage(msg.to,"Berhasil menghapus dari anggota BOTS")
                    else:
                        wait["dellbots"] = True
                        ais.sendMessage(msg.to,"Contact itu bukan anggota BOTS")
#=======================#
                 if msg._from in admin:
                  if wait["addstaff"] == True:
                    if msg.contentMetadata["mid"] in staff:
                        ais.sendMessage(msg.to,"Contact itu sudah jadi staff")
                        wait["addstaff"] = True
                    else:
                        staff.append(msg.contentMetadata["mid"])
                        wait["addstaff"] = True
                        ais.sendMessage(msg.to,"Berhasil menambahkan ke staff")
                 if wait["dellstaff"] == True:
                    if msg.contentMetadata["mid"] in staff:
                        staff.remove(msg.contentMetadata["mid"])
                        ais.sendMessage(msg.to,"Berhasil menghapus dari staff")
                        wait["dellstaff"] = True
                    else:
                        wait["dellstaff"] = True
                        ais.sendMessage(msg.to,"Contact itu bukan staff")
#=======================#
                 if msg._from in admin:
                  if wait["addadmin"] == True:
                    if msg.contentMetadata["mid"] in admin:
                        ais.sendMessage(msg.to,"Contact itu sudah jadi admin")
                        wait["addadmin"] = True
                    else:
                        admin.append(msg.contentMetadata["mid"])
                        wait["addadmin"] = True
                        ais.sendMessage(msg.to,"Berhasil menambahkan ke admin")
                 if wait["delladmin"] == True:
                    if msg.contentMetadata["mid"] in admin:
                        admin.remove(msg.contentMetadata["mid"])
                        ais.sendMessage(msg.to,"Berhasil menghapus dari admin")
                    else:
                        wait["delladmin"] = True
                        ais.sendMessage(msg.to,"Contact itu jago desah")
#===========ADD BLACKLIST============#
                 if msg._from in admin:
                  if wait["wblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["blacklist"]:
                        ais.sendMessage(msg.to,"Contact itu sudah ada di blacklist")
                        wait["wblacklist"] = True
                    else:
                        wait["blacklist"][msg.contentMetadata["mid"]] = True
                        wait["wblacklist"] = True
                        ais.sendMessage(msg.to,"Berhasil menambahkan ke blacklist user")
                  if wait["dblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["blacklist"]:
                        del wait["blacklist"][msg.contentMetadata["mid"]]
                        ais.sendMessage(msg.to,"Berhasil menghapus dari blacklist user")
                    else:
                        wait["dblacklist"] = True
                        ais.sendMessage(msg.to,"Contact itu tidak ada di blacklist")
#===========TALKBAN============#
                 if msg._from in admin:
                  if wait["Talkwblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["Talkblacklist"]:
                        ais.sendMessage(msg.to,"Contact itu sudah ada di Talkban")
                        wait["Talkwblacklist"] = True
                    else:
                        wait["Talkblacklist"][msg.contentMetadata["mid"]] = True
                        wait["Talkwblacklist"] = True
                        ais.sendMessage(msg.to,"Berhasil menambahkan ke Talkban user")
                  if wait["Talkdblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["Talkblacklist"]:
                        del wait["Talkblacklist"][msg.contentMetadata["mid"]]
                        ais.sendMessage(msg.to,"Berhasil menghapus dari Talkban user")
                    else:
                        wait["Talkdblacklist"] = True
                        ais.sendMessage(msg.to,"Contact itu tidak ada di Talkban")
#===========UPDATE FOTO============#
               if msg.contentType == 1:
                 if msg._from in admin:
                    if Setmain["Addimage"] == True:
                        msgid = msg.id
                        fotoo = "https://obs.line-apps.com/talk/m/download.nhn?oid="+msgid
                        headers = ais.Talk.Headers
                        r = requests.get(fotoo, headers=headers, stream=True)
                        if r.status_code == 200:
                            path = os.path.join(os.path.dirname(__file__), 'dataPhotos/%s.jpg' % Setmain["Img"])
                            with open(path, 'wb') as fp:
                                shutil.copyfileobj(r.raw, fp)
                            ais.sendMessage(msg.to, "Berhasil menambahkan gambar")
                        Setmain["Img"] = {}
                        Setmain["Addimage"] = False

               if msg.toType == 2:
                 if msg._from in admin:
                   if settings["groupPicture"] == True:
                     path = ais.downloadObjectMsg(msg_id)
                     settings["groupPicture"] = False
                     ais.updateGroupPicture(msg.to, path)
                     ais.sendMessage(msg.to, "Berhasil mengubah foto group")

               if msg.contentType == 1:
                   if msg._from in admin:
                       if mid in Setmain["SCfoto"]:
                            path = ais.downloadObjectMsg(msg_id)
                            del Setmain["SCfoto"][mid]
                            ais.updateProfilePicture(path)
                            ais.sendMessage(msg.to,"Foto berhasil dirubah")

               if msg.contentType == 1:
                 if msg._from in admin:
                   if settings["changePicture"] == True:
                     path1 = a1.downloadObjectMsg(msg_id)
                     path2 = a2.downloadObjectMsg(msg_id)
                     path3 = a3.downloadObjectMsg(msg_id)
                     path4 = a4.downloadObjectMsg(msg_id)
                     path5 = a5.downloadObjectMsg(msg_id)
                     path6 = ajs.downloadObjectMsg(msg_id)
                     settings["changePicture"] = False
                     a1.updateProfilePicture(path1)
                     a1.sendMessage(msg.to, "Berhasil mengubah foto profile bot")
                     a2.updateProfilePicture(path2)
                     a2.sendMessage(msg.to, "Berhasil mengubah foto profile bot")
                     a3.updateProfilePicture(path3)
                     a3.sendMessage(msg.to, "Berhasil mengubah foto profile bot")
                     a4.updateProfilePicture(path4)
                     a4.sendMessage(msg.to, "Berhasil mengubah foto profile bot")
                     a5.updateProfilePicture(path5)
                     a5.sendMessage(msg.to, "Berhasil mengubah foto profile bot")
                     ajs.updateProfilePicture(path6)
                     ajs.sendMessage(msg.to, "Berhasil mengubah foto profile bot")
               if msg.contentType == 0:
                    if Setmain["autoRead"] == True:
                        ais.sendChatChecked(msg.to, msg_id)
                    if text is None:
                        return
                    else:
                        cmd = command(text)
                        if cmd == "helpme":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               helpMessage = help()
                               ais.sendMessage(msg.to, str(helpMessage))
                                                                                                                                   
                        elif cmd == "helpbot":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               helpMessage1 = helpbot()
                               ais.sendMessage(msg.to, str(helpMessage1))
                               
                        elif cmd == "help pro":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               helpMessage2 = infomeme()
                               ais.sendMessage(msg.to, str(helpMessage2))

                        if cmd == "unsend on":
                            if msg._from in admin:
                                wait["unsend"] = True
                                ais.sendMessage(msg.to, "✯͜͡❂➣ Deteksi Unsend Diaktifkan")
                                
                        if cmd == "unsend off":
                            if msg._from in admin:
                                wait["unsend"] = False
                                ais.sendMessage(msg.to, "✯͜͡❂➣ Deteksi Unsend Dinonaktifkan")                                

                        elif cmd == "status":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                tz = pytz.timezone("Asia/Jakarta")
                                timeNow = datetime.now(tz=tz)
                                md = "  ┏━\n┃┃ ✯ ♠️ MERANA S T A T U S ♠️✯┃┣━\n"
                                if wait["unsend"] == True: md+="┃┃ [✔] Unsend「ON」\n"
                                else: md+="┃┃ [❌] Unsend「OFF」\n"                                
                                if wait["sticker"] == True: md+="┃┃ [✔] Sticker「ON」\n"
                                else: md+="┃┃ [❌] Sticker「OFF」\n"
                                if wait["contact"] == True: md+="┃┃ [✔] Contact「ON」\n"
                                else: md+="┃┃ [❌] Contact「OFF」\n"
                                if wait["talkban"] == True: md+="┃┃ [✔] Talkban「ON」\n"
                                else: md+="┃┃ [❌] Mode NIKUNG「OFF」\n"
                                if wait["Mentionkick"] == True: md+="┃┃ [✔] Notag「ON」\n"
                                else: md+="┃┃ [❌] Mode SANGE「OFF」\n"
                                if wait["detectMention"] == True: md+="┃┃ [✔] Respon「ON」\n"
                                else: md+="┃┃ [❌] Respon「OFF」\n"
                                if wait["Mentiongift"] == True: md+="┃┃ [✔] Respongift「ON」\n"
                                else: md+="┃┃ [❌] Respongift「OFF」\n"                                
                                if wait["autoJoin"] == True: md+="┃┃ [✔] Autojoin「ON」\n"
                                else: md+="┃┃ [❌] Autojoin「OFF」\n"
                                if settings["autoJoinTicket"] == True: md+="┃┃ [✔] Jointicket「ON」\n"
                                else: md+="┃┃ [❌] Jointicket「OFF」\n"                                
                                if wait["autoAdd"] == True: md+="┃┃ [✔] Autoadd「ON」\n"
                                else: md+="┃┃ [❌] Autoadd「OFF」\n"
                                if msg.to in welcome: md+="┃┃ [✔] Welcome「ON」\n"
                                else: md+="┃┃ [❌] Welcome「OFF」\n"
                                if wait["cjs"] == True: md+="┃┃ [✔] Purge「ON」\n"
                                else: md+="┃┃ [❌] Purge「OFF」\n"
                                if wait["qr"] == True: md+="┃┃ [✔] Protecturl「ON」\n"
                                else: md+="┃┃ [❌] Protecturl「OFF」\n"
                                if wait["joinan"] == True: md+="┃┃ [✔] Protectjoin「ON」\n"
                                else: md+="┃┃ [❌] Protectjoin「OFF」\n"
                                if wait["kick"] == True: md+="┃┃ [✔] Protectkick「ON」\n"
                                else: md+="┃┃ [❌] Protectkick「OFF」\n"
                                if wait["cancel"] == True: md+="┃┃ [✔] Protectcancel「ON」\n"
                                else: md+="┃┃ [❌] Protectcancel「OFF」\n"
                                if wait["vit"] == True: md+="┃┃ [✔] Protectinvite「ON」\n"
                                else: md+="┃┃ [❌] Protectinvite「OFF」\n"
                                if wait["js"] == True: md+="┃┃ [✔] Protectantijs「ON」\n"
                                else: md+="┃┃ [❌] Protectantijs「OFF」\n"
                                if wait["gs"] == True: md+="┃┃ [✔] Ghost「ON」\n"
                                else: md+="┃┃ [❌] Ghost「OFF」\n"
                                ais.sendMessage(msg.to, md+"┃┣━━━━━━━━━━━━━━━\n┃┃❧ Tanggal : "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\n┃┃❧ Jam [ "+ datetime.strftime(timeNow,'%H:%M:%S')+" ]\n  ┗━━━━━━━━━━━━━━━")

                        elif cmd == "baper" or text.lower() == 'lemper':
                            ais.sendImageWithURL(msg.to,"puskun aja kak") 
                        elif cmd == "pm" or text.lower() == 'pm bentar':
                            ais.sendMessage(msg.to, "bohong kak gosongin aja pm'nya")
                        elif cmd == "kojom" or text.lower() == 'mojok':
                            ais.sendMessage(msg.to, "hadehhhh ke laku aja km kak")
                        elif cmd == "sue" or text.lower() == 'suek':
                            ais.sendMessage(msg.to, "mumpung gk ada orang liat suek gk clananya kak")
                        elif cmd == "dudul" or text.lower() == 'dodol':
                            ais.sendMessage(msg.to, "iya,  kayaknya sih gitu dia memang dudul kak")
                        elif cmd == "asem" or text.lower() == 'sem':
                            ais.sendMessage(msg.to, "asem manis pedas sudah siap kak")
                        elif cmd == "nah" or text.lower() == 'nah':
                            ais.sendMessage(msg.to, "kenapa kak, lupa siram WC yah")
                        elif cmd == "bot" or text.lower() == 'botak':
                            ais.sendMessage(msg.to, "apa aim bukan bot")
                        elif cmd == "bah" or text.lower() == 'bahh':
                            ais.sendMessage(msg.to, "horas bah.., habis beras makan gabah")
                        elif cmd == "naik" or text.lower() == 'naik':
                            ais.sendMessage(msg.to, "Ogahh naik aja sendiri sono kak")
                        elif cmd == "assalamualaikum" or text.lower() == 'asalamualaikum':
                            ais.sendMessage(msg.to, "waalaikumsalam kak ")
                        elif cmd == "limiiit" or text.lower() == 'banchat':
                            ais.sendMessage(msg.to, "beli lg aja kak kan masih banyak")
                        elif cmd == "assalamualaikum" or text.lower() == 'asalamualaikum':
                            ais.sendMessage(msg.to, "waalaikumsalam kaka")
                          
                        elif cmd == "creator" or text.lower() == 'creator':
                            if msg._from in admin:
                                ais.sendMessage(msg.to,"Creator BOTS") 
                                ma = ""
                                for i in creator:
                                    ma = ais.getContact(i)
                                    ais.sendMessage(msg.to, None, contentMetadata={'mid': i}, contentType=13)

                        elif cmd == "me" or text.lower() == 'me':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               msg.contentType = 13
                               msg.contentMetadata = {'mid': msg._from}
                               ais.sendMessage(msg.to,"􀌂􀄲􏿿")
                               ais.sendContact(to, mid)

                        elif text.lower() == "mymid":
                            if msg._from in admin:
                               ais.sendMessage(msg.to, msg._from)

                        elif ("mid " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key1 = key["MENTIONEES"][0]["M"]
                               mi = ais.getContact(key1)
                               ais.sendMessage(msg.to, "Nama : "+str(mi.displayName)+"\nMID : " +key1)
                               ais.sendMessage(msg.to, None, contentMetadata={'mid': key1}, contentType=13)

                        elif ("info " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key1 = key["MENTIONEES"][0]["M"]
                               mi = ais.getContact(key1)
                               ais.sendMessage(msg.to, "❧ Nama : "+str(mi.displayName)+"\n=  Mid : " +key1+"\n=  Status : "+str(mi.statusMessage))
                               ais.sendMessage(msg.to, None, contentMetadata={'mid': key1}, contentType=13)
                               if "videoProfile='{" in str(ais.getContact(key1)):
                                   ais.sendVideoWithURL(msg.to, 'http://dl.profile.line.naver.jp'+str(mi.picturePath)+'/vp.small')
                               else:
                                   ais.sendImageWithURL(msg.to, 'http://dl.profile.line.naver.jp'+str(mi.picturePath))

                        elif cmd == "mybot":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               msg.contentType = 13
                               msg.contentMetadata = {'mid': mid}
                               ais.sendMessage1(msg)
                               msg.contentType = 13
                               msg.contentMetadata = {'mid': Amid}
                               ais.sendMessage1(msg)
                               msg.contentType = 13
                               msg.contentMetadata = {'mid': Bmid}
                               ais.sendMessage1(msg)
                               msg.contentType = 13
                               msg.contentMetadata = {'mid': Cmid}
                               ais.sendMessage1(msg)
                               msg.contentType = 13
                               msg.contentMetadata = {'mid': Dmid}
                               ais.sendMessage1(msg)
                               msg.contentType = 13
                               msg.contentMetadata = {'mid': Emid}
                               ais.sendMessage1(msg)
                               msg.contentType = 13
                               msg.contentMetadata = {'mid': Xmid}
                               ais.sendMessage1(msg)

                        elif text.lower() == "rchat":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               try:
                                   ais.removeAllMessages(op.param2)
                                   ais.sendMessage(msg.to,"°❂➤「Succᴇs ᴄʟᴇᴀʀ. ")
                                   a1.removeAllMessages(op.param2)
                                   a1.sendMessage(msg.to,"°❂➤「Succᴇs ᴄʟᴇᴀʀ. ")
                                   a2.removeAllMessages(op.param2)
                                   a2.sendMessage(msg.to,"°❂➤「Succᴇs ᴄʟᴇᴀʀ. ")
                                   a3.removeAllMessages(op.param2)
                                   a3.sendMessage(msg.to,"°❂➤「Succᴇs ᴄʟᴇᴀʀ. ")
                                   a4.removeAllMessages(op.param2)
                                   a4.sendMessage(msg.to,"°❂➤「Succᴇs ᴄʟᴇᴀʀ. ")
                                   a5.removeAllMessages(op.param2)
                                   a5.sendMessage(msg.to,"°❂➤「Succᴇs ᴄʟᴇᴀʀ. ")
                                   a5.removeAllMessages(op.param2)
                                   a5.sendMessage(msg.to,"°❂➤「Succᴇs ᴄʟᴇᴀʀ. ")
                               except:
                                   pass

                        elif cmd.startswith("broadcast: "):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               sep = text.split(" ")
                               pesan = text.replace(sep[0] + " ","")
                               saya = ais.getGroupIdsJoined()
                               for group in saya:
                                   ais.sendMessage(group,"=======[BROADCAST]=======\n\n"+pesan+"\n\nFunkzher")

                            
                        elif cmd == "runtime":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               eltime = time.time() - mulai
                               bot = "Aktif " +waktu(eltime)
                               ais.sendMessage(msg.to,bot)
                            
                        elif cmd == "ginfo":
                          if msg._from in admin:
                            try:
                                G = ais.getGroup(msg.to)
                                if G.invitee is None:
                                    gPending = "0"
                                else:
                                    gPending = str(len(G.invitee))
                                if G.preventedJoinByTicket == True:
                                    gQr = "Tertutup"
                                    gTicket = "Tidak ada"
                                else:
                                    gQr = "Terbuka"
                                    gTicket = "https://line.me/R/ti/g/{}".format(str(ais.reissueGroupTicket(G.id)))
                                timeCreated = []
                                timeCreated.append(time.strftime("%d-%m-%Y [ %H:%M:%S ]", time.localtime(int(G.createdTime) / 1000)))
                                ais.sendMessage(msg.to, "❧ BOT Grup Info\n\n ❧ Nama Group : {}".format(G.name)+ "\n=  ID Group : {}".format(G.id)+ "\n=  Pembuat : {}".format(G.creator.displayName)+ "\n=  Waktu Dibuat : {}".format(str(timeCreated))+ "\n=  Jumlah Member : {}".format(str(len(G.members)))+ "\n=  Jumlah Pending : {}".format(gPending)+ "\n=  Group Qr : {}".format(gQr)+ "\n=  Group Ticket : {}".format(gTicket))
                                ais.sendMessage(msg.to, None, contentMetadata={'mid': G.creator.mid}, contentType=13)
                                ais.sendImageWithURL(msg.to, 'http://dl.profile.line-cdn.net/'+G.pictureStatus)
                            except Exception as e:
                                ais.sendMessage(msg.to, str(e))

                        elif cmd.startswith("infogrup "):
                          if msg._from in admin:
                            separate = text.split(" ")
                            number = text.replace(separate[0] + " ","")
                            groups = ais.getGroupIdsJoined()
                            ret_ = ""
                            try:
                                group = groups[int(number)-1]
                                G = ais.getGroup(group)
                                try:
                                    gCreator = G.creator.displayName
                                except:
                                    gCreator = "Tidak ditemukan"
                                if G.invitee is None:
                                    gPending = "0"
                                else:
                                    gPending = str(len(G.invitee))
                                if G.preventedJoinByTicket == True:
                                    gQr = "Tertutup"
                                    gTicket = "Tidak ada"
                                else:
                                    gQr = "Terbuka"
                                    gTicket = "https://line.me/R/ti/g/{}".format(str(ais.reissueGroupTicket(G.id)))
                                timeCreated = []
                                timeCreated.append(time.strftime("%d-%m-%Y [ %H:%M:%S ]", time.localtime(int(G.createdTime) / 1000)))
                                ret_ += "✯͜͡❂➣  BOT Grup Info\n"
                                ret_ += "\n✯͜͡❂➣  Name : {}".format(G.name)
                                ret_ += "\n✯͜͡❂➣  ID : {}".format(G.id)
                                ret_ += "\n✯͜͡❂➣  Creator : {}".format(gCreator)
                                ret_ += "\n✯͜͡❂➣  Created Time : {}".format(str(timeCreated))
                                ret_ += "\n✯͜͡❂➣  Member : {}".format(str(len(G.members)))
                                ret_ += "\n✯͜͡❂➣  Pending : {}".format(gPending)
                                ret_ += "\n✯͜͡❂➣  Qr : {}".format(gQr)
                                ret_ += "\n✯͜͡❂➣  Ticket : {}".format(gTicket)
                                ret_ += ""
                                ais.sendMessage(to, str(ret_))
                            except:
                                pass

                        elif cmd.startswith("infomem "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            number = msg.text.replace(separate[0] + " ","")
                            groups = ais.getGroupIdsJoined()
                            ret_ = ""
                            try:
                                group = groups[int(number)-1]
                                G = ais.getGroup(group)
                                no = 0
                                ret_ = ""
                                for mem in G.members:
                                    no += 1
                                    ret_ += "\n " "✯͜͡❂➣  "+ str(no) + ". " + mem.displayName
                                ais.sendMessage(to,"✯͜͡❂➣  Group Name : [ " + str(G.name) + " ]\n\n   [ List Member ]\n" + ret_ + "\n\n「Total %i Members」" % len(G.members))
                            except: 
                                pass

                        elif cmd.startswith("leave: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            number = msg.text.replace(separate[0] + " ","")
                            groups = ais.getGroupIdsJoined()
                            group = groups[int(number)-1]
                            for i in group:
                                ginfo = ais.getGroup(i)
                                if ginfo == group:
                                    ki.leaveGroup(i)
                                    ais.sendMessage(msg.to,"Berhasil keluar di grup " +str(ginfo.name))

                        elif cmd == "friendlist":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               ma = ""
                               a = 0
                               gid = ais.getAllContactIds()
                               for i in gid:
                                   G = ais.getContact(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "┃┃ " + str(a) + ". " +G.displayName+ "\n"
                               ais.sendMessage(msg.to,"┏━━[ FRIEND LIST ]\n┃┃\n"+ma+"┃┃\n┗━━[ Total「"+str(len(gid))+"」Friends ]")

                        elif cmd == "gruplist":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               ma = ""
                               a = 0
                               gid = ais.getGroupIdsJoined()
                               for i in gid:
                                   G = ais.getGroup(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "┃┃ " + str(a) + ". " +G.name+ "\n"
                               ais.sendMessage(msg.to,"┏━━[ GROUP LIST ]\n┃┃\n"+ma+"┃┃\n┗━━[ Total「"+str(len(gid))+"」Groups ]")

                        elif cmd == "gruplist1":
                            if msg._from in admin:
                               ma = ""
                               a = 0
                               gid = ki.getGroupIdsJoined()
                               for i in gid:
                                   G = ki.getGroup(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "┃┃ " + str(a) + ". " +G.name+ "\n"
                               ki.sendMessage(msg.to,"┏━━[ GROUP LIST ]\n┃┃\n"+ma+"┃┃\n┗━━[ Total「"+str(len(gid))+"」Groups ]")


                        elif cmd == "open":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                if msg.toType == 2:
                                   X = ki.getGroup(msg.to)
                                   X.preventedJoinByTicket = False
                                   ki.updateGroup(X)
                                   ki.sendMessage(msg.to, "Url Opened")

                        elif cmd == "close":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                if msg.toType == 2:
                                   X = ki.getGroup(msg.to)
                                   X.preventedJoinByTicket = True
                                   ki.updateGroup(X)
                                   ki.sendMessage(msg.to, "Url Closed")

                        elif cmd == "url grup":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                if msg.toType == 2:
                                   x = ki.getGroup(msg.to)
                                   if x.preventedJoinByTicket == True:
                                      x.preventedJoinByTicket = False
                                      ki.updateGroup(x)
                                   gurl = ki.reissueGroupTicket(msg.to)
                                   ki.sendMessage(msg.to, "Nama : "+str(x.name)+ "\nUrl grup : http://line.me/R/ti/g/"+gurl)

                        elif cmd == "invitelist" or cmd == "listinvite":
                          if msg._from in admin:
                            groups = ais.getGroupIdsInvited()
                            ret_ = "====「 Invitation List 」"
                            no = 1
                            for gid in groups:
                                group = ais.getGroup(gid)
                                ret_ += "\n│•{}. {} | {}".format(str(no), str(group.name), str(len(group.members)))
                                no = (no+1)
                            ret_ += "\n│Total {} Pending".format(str(len(groups)))
                            ret_ += "\n├───「 Usage 」───"
                            ret_ += "\n├Accept 「Nomor」"
                            ret_ += "\n├Reject 「Nomor」"
                            ret_ += "\n====「 Funkzher Bot 」"
                            ais.sendMessage(msg.to, str(ret_))

                        elif cmd == "reject":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              ginvited = ais.getGroupIdsInvited()
                              if ginvited != [] and ginvited != None:
                                  for gid in ginvited:
                                      time.sleep(3)
                                      ais.rejectGroupInvitation(gid)
                                  ais.sendMessage(msg.to, "♪ᶠᵇᵏ Succes Reject {} Group Invite".format(str(len(ginvited))))
                              else:
                                  ais.sendMessage(msg.to, "♪ᶠᵇᵏno thing")

#===========BOT UPDATE============#
                        elif cmd == "updategrup":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              if msg.toType == 2:
                                settings["groupPicture"] = True
                                ais.sendMessage(msg.to,"Kirim fotonya.....")

                        elif cmd == "fotobot":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                settings["changePicture"] = True
                                ais.sendMessage(msg.to,"Kirim fotonya.....")
                                
                        elif cmd == "foto induk":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                Setmain["SCfoto"][mid] = True
                                ais.sendMessage(msg.to,"Kirim fotonya.....")

                        elif cmd == "up1foto":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                Setmain["SCfoto"][Amid] = True
                                a1.sendMessage(msg.to,"Kirim fotonya.....")

                        elif cmd == "up2foto":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                Setmain["SCfoto"][Bmid] = True
                                a2.sendMessage(msg.to,"Kirim fotonya.....")

                        elif cmd == "up3foto":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                Setmain["SCfoto"][Cmid] = True
                                a3.sendMessage(msg.to,"Kirim fotonya.....")

                        elif cmd == "up4foto":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                Setmain["SCfoto"][Dmid] = True
                                a4.sendMessage(msg.to,"Kirim fotonya.....")

                        elif cmd == "up5foto":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                Setmain["SCfoto"][Emid] = True
                                a5.sendMessage(msg.to,"Kirim fotonya.....")

                        elif cmd == "up6foto":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                Setmain["SCfoto"][Xmid] = True
                                ajs.sendMessage(msg.to,"Kirim fotonya.....")

                        elif cmd.startswith("myname: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = ais.getProfile()
                                profile.displayName = string
                                ais.updateProfile(profile)
                                ais.sendMessage(msg.to,"Nama diganti jadi " + string + "")


                        elif cmd.startswith("name1: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = ais.getProfile()
                                profile.displayName = string
                                a1.updateProfile(profile)
                                a1.sendMessage(msg.to,"Nama diganti jadi " + string + "")

                        elif cmd.startswith("name2: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = ais.getProfile()
                                profile.displayName = string
                                a2.updateProfile(profile)
                                a2.sendMessage(msg.to,"Nama diganti jadi " + string + "")

                        elif cmd.startswith("name3: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = ais.getProfile()
                                profile.displayName = string
                                a3.updateProfile(profile)
                                a3.sendMessage(msg.to,"Nama diganti jadi " + string + "")

                        elif cmd.startswith("name4: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = ais.getProfile()
                                profile.displayName = string
                                a4.updateProfile(profile)
                                a4.sendMessage(msg.to,"Nama diganti jadi " + string + "")

                        elif cmd.startswith("name5: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = ais.getProfile()
                                profile.displayName = string
                                a5.updateProfile(profile)
                                a5.sendMessage(msg.to,"Nama diganti jadi " + string + "")

                        elif cmd.startswith("name6: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = ais.getProfile()
                                profile.displayName = string
                                ajs.updateProfile(profile)
                                ajs.sendMessage(msg.to,"Nama diganti jadi " + string + "")
#===========BOT UPDATE============#
                        elif cmd.startswith("tag: "):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                            	separate = msg.text.split(":")
                            	number = msg.text.replace(separate[0] + ":"," ")
                            	groups = ais.getGroupIdsJoined()
                            	gid = groups[int(number)-1]                                                            
                            	group = ais.getGroup(gid)                                                            
                            	nama = [contact.mid for contact in group.members]
                            	k = len(nama)//20
                    	        for a in range(k+1):
                            		txt = u''
                    		        s=0
                            		b=[]
                            		for i in group.members[a*20 : (a+1)*20]:
                            			b.append(i.mid)
                            		mentionMembers1(gid, b)                            
                    		        ais.sendMessage(msg.to, "Berhasil Mention Member di Group: \n " + str(group.name))


                        elif cmd == "tag" or text.lower() == "bro":
                           if wait["selfbot"] == True:
                            if msg._from in admin:
                             group = ais.getGroup(msg.to)
                            nama = [contact.mid for contact in group.members]
                            k = len(nama)//20
                            for a in range(k+1):
                                txt = u''
                                s=0
                                b=[]
                                for i in group.members[a*20 : (a+1)*20]:
                                    b.append(i.mid)
                                mentionMembers1(msg.to, b)

                        elif cmd == "listbot":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                ma = ""
                                a = 0
                                for m_id in Bots:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +ais.getContact(m_id).displayName + "\n"
                                ais.sendMessage(msg.to,"✯͜͡❂➣  BOTS\n\n"+ma+"\nTotal「%s」BOTS" %(str(len(Bots))))

                        elif cmd == "listadmin":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                ma = ""
                                mb = ""
                                mc = ""
                                a = 0
                                b = 0
                                c = 0
                                for m_id in owner:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +ais.getContact(m_id).displayName + "\n"
                                for m_id in admin:
                                    b = b + 1
                                    end = '\n'
                                    mb += str(b) + ". " +ais.getContact(m_id).displayName + "\n"
                                for m_id in staff:
                                    c = c + 1
                                    end = '\n'
                                    mc += str(c) + ". " +ais.getContact(m_id).displayName + "\n"
                                ais.sendMessage(msg.to,"✯͜͡❂➣  Admin BOT\n\n✯͜͡❂➣ Creator BOT:\n"+ma+"\n✯͜͡❂➣ Admin:\n"+mb+"\n✯͜͡❂➣ Staff:\n"+mc+"\n✯͜͡❂➣ Total「%s」" %(str(len(owner)+len(admin)+len(staff))))

                        elif cmd == "listprotect":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                ma = ""
                                mb = ""
                                mc = ""
                                md = ""
                                me = ""
                                a = 0
                                b = 0
                                c = 0
                                d = 0
                                e = 0
                                gid = protectqr
                                for group in gid:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +ais.getGroup(group).name + "\n"
                                gid = protectkick
                                for group in gid:
                                    b = b + 1
                                    end = '\n'
                                    mb += str(b) + ". " +ais.getGroup(group).name + "\n"
                                gid = protectjoin
                                for group in gid:
                                    d = d + 1
                                    end = '\n'
                                    md += str(d) + ". " +ais.getGroup(group).name + "\n"
                                gid = protectcancel
                                for group in gid:
                                    c = c + 1
                                    end = '\n'
                                    mc += str(c) + ". " +ais.getGroup(group).name + "\n"
                                gid = protectinvite
                                for group in gid:
                                    e = e + 1
                                    end = '\n'
                                    me += str(e) + ". " +ais.getGroup(group).name + "\n"                                    
                                ais.sendMessage(msg.to,"✯͜͡❂➣  BOT Protection\n\n✯͜͡❂➣  PROTECT URL :\n"+ma+"\n✯͜͡❂➣  PROTECT KICK :\n"+mb+"\n✯͜͡❂➣  PROTECT JOIN :\n"+md+"\n✯͜͡❂➣  PROTECT CANCEL:\n"+mc+"\n✯͜͡❂➣  PROTECT INVITE :\n"+me+"\nTotal「%s」Protect yang aktif" %(str(len(protectqr)+len(protectkick)+len(protectjoin)+len(protectcancel)+len(protectinvite))))

                        elif cmd == "respon":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                a1.sendMessage(msg.to,"hadir....")
                                a2.sendMessage(msg.to,"hadir....")
                                a3.sendMessage(msg.to,"hadir....")
                                a4.sendMessage(msg.to,"hadir....")
                                a5.sendMessage(msg.to,"hadir....")
                                a5.sendMessage(msg.to,"hadir....")

                        elif cmd == "invitebot":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                try:
                                    anggota = [Amid,Bmid,Cmid,Dmid,Emid,Xmid]
                                    ais.inviteIntoGroup(msg.to, anggota)
                                    time.sleep(3)
                                    a1.acceptGroupInvitation(msg.to)
                                    time.sleep(3)
                                    a2.acceptGroupInvitation(msg.to)
                                    time.sleep(3)
                                    a3.acceptGroupInvitation(msg.to)
                                    time.sleep(3)
                                    a4.acceptGroupInvitation(msg.to)
                                    time.sleep(3)
                                    a5.acceptGroupInvitation(msg.to)
                                except:
                                    pass
                                
    
                        elif cmd == "joinall":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                G = ais.getGroup(msg.to)
                                G.preventedJoinByTicket = False
                                ais.updateGroup(G)
                                invsend = 0
                                Ticket = ais.reissueGroupTicket(msg.to)
                                time.sleep(3)
                                a1.acceptGroupInvitationByTicket(msg.to,Ticket)
                                time.sleep(3)
                                a2.acceptGroupInvitationByTicket(msg.to,Ticket)
                                time.sleep(3)
                                a3.acceptGroupInvitationByTicket(msg.to,Ticket)
                                time.sleep(3)
                                a4.acceptGroupInvitationByTicket(msg.to,Ticket)
                                time.sleep(3)
                                a5.acceptGroupInvitationByTicket(msg.to,Ticket)
                                G = ais.getGroup(msg.to)
                                G.preventedJoinByTicket = True
                                ais.updateGroup(G)
                                ginfo = ais.getGroup(msg.to)
                                ais.inviteIntoGroup(op.param1,[Xmid])

                        elif cmd == "byeall":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                a1.leaveGroup(msg.to)
                                a2.leaveGroup(msg.to)
                                a3.leaveGroup(msg.to)
                                a4.leaveGroup(msg.to)                                
                                a5.leaveGroup(msg.to)                                
                                a5.leaveGroup(msg.to)
                                ginfo = ais.getGroup(msg.to)
                                ais.inviteIntoGroup(op.param1,[Xmid])

                        elif cmd == "byeme":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                G = ais.getGroup(msg.to)
                                ais.leaveGroup(msg.to)
                                
                        elif cmd == "js in":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                G = ais.getGroup(msg.to)
                                ginfo = ais.getGroup(msg.to)
                                G.preventedJoinByTicket = False
                                ais.updateGroup(G)
                                Ticket = ais.reissueGroupTicket(msg.to)
                                ajs.acceptGroupInvitationByTicket(msg.to,Ticket)
                                G = ajs.getGroup(msg.to)
                                G.preventedJoinByTicket = True
                                ajs.updateGroup(G)

                        elif cmd == "js out":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                G = ais.getGroup(msg.to)
                                ajs.leaveGroup(msg.to)
                                ginfo = ais.getGroup(msg.to)
                                ais.inviteIntoGroup(op.param1,[Xmid])


                        elif cmd.startswith("leave "):
                            if msg._from in admin:
                                proses = text.split(" ")
                                ng = text.replace(proses[0] + " ","")
                                gid = ais.getGroupIdsJoined()
                                for i in gid:
                                    h = ais.getGroup(i).name
                                    if h == ng:
                                        a1.sendMessage(i, "Silahkan admin invite atau masukan kembali")
                                        a1.leaveGroup(i)
                                        ais.sendMessage(to,"Berhasil keluar dari grup " +h)

                        elif cmd == "sprespon":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                get_profile_time_start = time.time()
                                get_profile = ais.getProfile()
                                get_profile_time = time.time() - get_profile_time_start
                                get_group_time_start = time.time()
                                get_group = ais.getGroupIdsJoined()
                                get_group_time = time.time() - get_group_time_start
                                get_contact_time_start = time.time()
                                get_contact = ais.getContact(mid)
                                get_contact_time = time.time() - get_contact_time_start
                                ais.sendMessage(msg.to, " ❧ BOT Speed respon\n\n - Get Profile\n   %.10f\n - Get Contact\n   %.10f\n - Get Group\n   %.10f" % (get_profile_time/3,get_contact_time/3,get_group_time/3))

                        elif cmd == "speed" or cmd == "sp":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               start = time.time()
                               ais.sendMessage(msg.to, "™❍✯͜͡speed...✯͜͡❂➣")
                               elapsed_time = time.time() - start
                               ais.sendMessage(msg.to, "{} detik".format(str(elapsed_time)))


                        elif cmd == "autoblock on":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoBlock"] = True
                                ais.sendMessage(msg.to, "Successfully activated")
                        elif cmd == "autoblock off":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoBlock"] = False
                                ais.sendMessage(msg.to, "Disable successfully")
                                
                        elif cmd == "sider on":
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                              try:
                                  tz = pytz.timezone("Asia/Jakarta")
                                  timeNow = datetime.now(tz=tz)
                                  ais.sendMessage(msg.to, "✯͜͡❂➣Cek sider diaktifkan\n\nTanggal : "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\nJam [ "+ datetime.strftime(timeNow,'%H:%M:%S')+" ]")
                                  ais.sendMessage(msg.to, None, contentMetadata={"STKID":"11789035","STKPKGID":"1291001","STKVER":"1"}, contentType=7)
                                  del cctv['point'][msg.to]
                                  del cctv['sidermem'][msg.to]
                                  del cctv['cyduk'][msg.to]
                              except:
                                  pass
                              cctv['point'][msg.to] = msg.id
                              cctv['sidermem'][msg.to] = ""
                              cctv['cyduk'][msg.to]=True

                        elif cmd == "sider off":
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                              if msg.to in cctv['point']:
                                  tz = pytz.timezone("Asia/Jakarta")
                                  timeNow = datetime.now(tz=tz)
                                  cctv['cyduk'][msg.to]=False
                                  ais.sendMessage(msg.to, "✯͜͡❂➣Cek sider dinonaktifkan\n\nTanggal : "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\nJam [ "+ datetime.strftime(timeNow,'%H:%M:%S')+" ]")
                                  ais.sendMessage(msg.to, None, contentMetadata={"STKID":"15439592","STKPKGID":"1398071","STKVER":"1"}, contentType=7)
                              else:
                                  ais.sendMessage(msg.to, "Sudak tidak aktif")
        
#==============================================================================# 

                        elif 'Welcome ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Welcome ','')
                              if spl == 'on':
                                  if msg.to in welcome:
                                       msgs = "✯͜͡❂➣ Welcome Msg sudah aktif"
                                  else:
                                       welcome.append(msg.to)
                                       ginfo = ais.getGroup(msg.to)
                                       msgs = "Welcome Msg diaktifkan\nDi Group : " +str(ginfo.name)
                                  ais.sendMessage(msg.to, "「Diaktifkan」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in welcome:
                                         welcome.remove(msg.to)
                                         ginfo = ais.getGroup(msg.to)
                                         msgs = "Welcome Msg dinonaktifkan\nDi Group : " +str(ginfo.name)
                                    else:
                                         msgs = "✯͜͡❂➣ Welcome Msg sudah tidak aktif"
                                    ais.sendMessage(msg.to, "「Dinonaktifkan」\n" + msgs)
                                    
#===========Protection============#                                    

                        elif 'Protecturl ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Protecturl ','')
                              if spl == 'on':
                                  if msg.to in protectqr:
                                       msgs = "✯͜͡❂➣ Protect url sudah aktif"
                                  else:
                                       protectqr.append(msg.to)
                                       ginfo = ais.getGroup(msg.to)
                                       msgs = "✯͜͡❂➣ Protect url diaktifkan\nDi Group : " +str(ginfo.name)
                                  ais.sendMessage(msg.to, "「Diaktifkan」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in protectqr:
                                         protectqr.remove(msg.to)
                                         ginfo = ais.getGroup(msg.to)
                                         msgs = "Protect url dinonaktifkan\nDi Group : " +str(ginfo.name)
                                    else:
                                         msgs = "✯͜͡❂➣ Protect url sudah tidak aktif"
                                    ais.sendMessage(msg.to, "「Dinonaktifkan」\n" + msgs)

                        elif 'Protectkick ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Protectkick ','')
                              if spl == 'on':
                                  if msg.to in protectkick:
                                       msgs = "✯͜͡❂➣ Protect kick sudah aktif"
                                  else:
                                       protectkick.append(msg.to)
                                       ginfo = ais.getGroup(msg.to)
                                       msgs = "✯͜͡❂➣ Protect kick diaktifkan\nDi Group : " +str(ginfo.name)
                                  ais.sendMessage(msg.to, "「Diaktifkan」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in protectkick:
                                         protectkick.remove(msg.to)
                                         ginfo = ais.getGroup(msg.to)
                                         msgs = "✯͜͡❂➣Protect kick dinonaktifkan\nDi Group : " +str(ginfo.name)
                                    else:
                                         msgs = "✯͜͡❂➣Protect kick sudah tidak aktif"
                                    ais.sendMessage(msg.to, "「Dinonaktifkan」\n" + msgs)

                        elif 'Protectjoin ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Protectjoin ','')
                              if spl == 'on':
                                  if msg.to in protectjoin:
                                       msgs = "✯͜͡❂➣ Protect join sudah aktif"
                                  else:
                                       protectjoin.append(msg.to)
                                       ginfo = ais.getGroup(msg.to)
                                       msgs = "✯͜͡❂➣ Protect join diaktifkan\nDi Group : " +str(ginfo.name)
                                  ais.sendMessage(msg.to, "「Diaktifkan」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in protectjoin:
                                         protectjoin.remove(msg.to)
                                         ginfo = ais.getGroup(msg.to)
                                         msgs = "✯͜͡❂➣ Protect join dinonaktifkan\nDi Group : " +str(ginfo.name)
                                    else:
                                         msgs = "✯͜͡❂➣ Protect join sudah tidak aktif"
                                    ais.sendMessage(msg.to, "「Dinonaktifkan」\n" + msgs)

                        elif 'Protectcancel ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Protectcancel ','')
                              if spl == 'on':
                                  if msg.to in protectcancel:
                                       msgs = "✯͜͡❂➣ Protect cancel sudah aktif"
                                  else:
                                       protectcancel.append(msg.to)
                                       ginfo = ais.getGroup(msg.to)
                                       msgs = "✯͜͡❂➣ Protect cancel diaktifkan\nDi Group : " +str(ginfo.name)
                                  ais.sendMessage(msg.to, "「Diaktifkan」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in protectcancel:
                                         protectcancel.remove(msg.to)
                                         ginfo = ais.getGroup(msg.to)
                                         msgs = "✯͜͡❂➣Protect cancel dinonaktifkan\nDi Group : " +str(ginfo.name)
                                    else:
                                         msgs = "✯͜͡❂➣Protect cancel sudah tidak aktif"
                                    ais.sendMessage(msg.to, "「Dinonaktifkan」\n" + msgs)
                                    
                        elif 'Protectinvite ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Protectinvite ','')
                              if spl == 'on':
                                  if msg.to in protectinvite:
                                       msgs = "✯͜͡❂➣ Protect invite sudah aktif"
                                  else:
                                       protectinvite.append(msg.to)
                                       ginfo = ais.getGroup(msg.to)
                                       msgs = "✯͜͡❂➣ Protect invite diaktifkan\nDi Group : " +str(ginfo.name)
                                  ais.sendMessage(msg.to, "「Diaktifkan」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in protectinvite:
                                         protectinvite.remove(msg.to)
                                         ginfo = ais.getGroup(msg.to)
                                         msgs = "✯͜͡❂➣Protect invite dinonaktifkan\nDi Group : " +str(ginfo.name)
                                    else:
                                         msgs = "✯͜͡❂➣Protect invite sudah tidak aktif"
                                    ais.sendMessage(msg.to, "「Dinonaktifkan」\n" + msgs)                                                                      

                        elif 'Allpro ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Allpro ','')
                              if spl == 'on':
                                  if msg.to in protectqr:
                                       msgs = ""
                                  else:
                                       protectqr.append(msg.to)
                                  if msg.to in protectkick:
                                      msgs = ""
                                  else:
                                      protectkick.append(msg.to)
                                  if msg.to in protectinvite:
                                      msgs = ""
                                  else:
                                      protectinvite.append(msg.to)                                      
                                  if msg.to in protectjoin:
                                      msgs = ""
                                  else:
                                      protectjoin.append(msg.to)
                                  if msg.to in protectcancel:
                                      ginfo = ais.getGroup(msg.to)
                                      msgs = "Semua protect sudah on\nDi Group : " +str(ginfo.name)
                                  else:
                                      protectcancel.append(msg.to)
                                      ginfo = ais.getGroup(msg.to)
                                      msgs = "Berhasil mengaktifkan semua protect\nDi Group : " +str(ginfo.name)
                                  ais.sendMessage(msg.to, "「Diaktifkan」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in protectqr:
                                         protectqr.remove(msg.to)
                                    else:
                                         msgs = ""
                                    if msg.to in protectkick:
                                         protectkick.remove(msg.to)
                                    else:
                                         msgs = ""
                                    if msg.to in protectinvite:
                                         protectinvite.remove(msg.to)
                                    else:
                                         msgs = ""                                         
                                    if msg.to in protectjoin:
                                         protectjoin.remove(msg.to)
                                    else:
                                         msgs = ""
                                    if msg.to in protectcancel:
                                         protectcancel.remove(msg.to)
                                         ginfo = ais.getGroup(msg.to)
                                         msgs = "Berhasil menonaktifkan semua protect\nDi Group : " +str(ginfo.name)
                                    else:
                                         ginfo = ais.getGroup(msg.to)
                                         msgs = "Semua protect sudah off\nDi Group : " +str(ginfo.name)
                                    ais.sendMessage(msg.to, "「Dinonaktifkan」\n" + msgs)

#===========KICKOUT============#


#===========ADMIN ADD============#
                        elif ("Adminadd " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in creator:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           admin[target] = True
                                           f=codecs.open('admin.json','w','utf-8')
                                           json.dump(admin, f, sort_keys=True, indent=4,ensure_ascii=False)                                            
                                           ais.sendMessage(msg.to,"Berhasil menambahkan admin")
                                       except:
                                           pass

                        elif ("Staffadd " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           staff.append(target)
                                           ais.sendMessage(msg.to,"Berhasil menambahkan staff")
                                       except:
                                           pass

                        elif ("Botadd " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           Bots.append(target)
                                           ais.sendMessage(msg.to,"Berhasil menambahkan bot")
                                       except:
                                           pass

                        elif ("Admindell " in msg.text):
                            if msg._from in creator:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           del admin[target]
                                           f=codecs.open('admin.json','w','utf-8')
                                           json.dump(admin, f, sort_keys=True, indent=4,ensure_ascii=False)                                            
                                           ais.sendMessage(msg.to,"Berhasil menghapus admin")
                                       except:
                                           pass

                        elif ("Staffdell " in msg.text):
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in admin:
                                       try:
                                           staff.remove(target)
                                           ais.sendMessage(msg.to,"Berhasil menghapus admin")
                                       except:
                                           pass

                        elif ("Botdell " in msg.text):
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in admin:
                                       try:
                                           Bots.remove(target)
                                           ais.sendMessage(msg.to,"Berhasil menghapus admin")
                                       except:
                                           pass

                        elif cmd == "admin:on" or text.lower() == 'admin:on':
                            if msg._from in admin:
                                wait["addadmin"] = True
                                ais.sendMessage(msg.to,"Kirim kontaknya...")

                        elif cmd == "admin:delete" or text.lower() == 'admin:delete':
                            if msg._from in admin:
                                wait["delladmin"] = True
                                ais.sendMessage(msg.to,"Kirim kontaknya...")

                        elif cmd == "staff:on" or text.lower() == 'staff:on':
                            if msg._from in admin:
                                wait["addstaff"] = True
                                ais.sendMessage(msg.to,"Kirim kontaknya...")

                        elif cmd == "staff:delete" or text.lower() == 'staff:delete':
                            if msg._from in admin:
                                wait["dellstaff"] = True
                                ais.sendMessage(msg.to,"Kirim kontaknya...")

                        elif cmd == "bot:on" or text.lower() == 'bot:on':
                            if msg._from in admin:
                                wait["addbots"] = True
                                ais.sendMessage(msg.to,"Kirim kontaknya...")

                        elif cmd == "bot:delete" or text.lower() == 'bot:delete':
                            if msg._from in admin:
                                wait["dellbots"] = True
                                ais.sendMessage(msg.to,"Kirim kontaknya...")

                        elif cmd == "refresh" or text.lower() == 'refresh':
                            if msg._from in admin:
                                wait["addadmin"] = False
                                wait["delladmin"] = False
                                wait["addstaff"] = False
                                wait["dellstaff"] = False
                                wait["addbots"] = False
                                wait["dellbots"] = False
                                wait["wblacklist"] = False
                                wait["dblacklist"] = False
                                wait["Talkwblacklist"] = False
                                wait["Talkdblacklist"] = False
                                ais.sendMessage(msg.to,"Berhasil di Refresh...")


                        elif cmd == "allpro off" or text.lower() == 'Allpro off':
                            if msg._from in admin:
                                wait["kick"] = False
                                wait["vit"] = False
                                wait["cjs"] = False
                                wait["qr"] = False
                                wait["gs"] = False
                                wait["joinan"] = False
                                wait["cancel"] = False
                                wait["Talkwblacklist"] = False
                                wait["Talkdblacklist"] = False
                                ais.sendMessage(msg.to,"Done tidak aktif bos...")

                        elif cmd == "allpro on" or text.lower() == 'Allpro on':
                            if msg._from in admin:
                                wait["kick"] = True
                                wait["vit"] = True
                                wait["cjs"] = True
                                wait["cancel"] = True
                                wait["js"] = True
                                wait["qr"] = True
                                wait["gs"] = True
                                wait["joinan"] = True
                                wait["Talkdblacklist"] = False
                                ais.sendMessage(msg.to,"Done aktif bos...")

                        elif cmd == "contact admin" or text.lower() == 'contact admin':
                                ma = ""
                                for i in admin:
                                    ma = a1.getContact(i)
                                    a1.sendMessage(msg.to, None, contentMetadata={'mid': i}, contentType=13)

                        elif cmd == "contact staff" or text.lower() == 'contact staff':
                                ma = ""
                                for i in staff:
                                    ma = a1.getContact(i)
                                    a1.sendMessage(msg.to, None, contentMetadata={'mid': i}, contentType=13)

                        elif cmd == "contact bot" or text.lower() == 'contact bot':
                                ma = ""
                                for i in Bots:
                                    ma = a1.getContact(i)
                                    a1.sendMessage(msg.to, None, contentMetadata={'mid': i}, contentType=13)


#===========COMMAND ON OFF============#
                        elif cmd == "joinan on" or text.lower() == 'notag on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["joinan"] = True
                                ais.sendMessage(msg.to,"Join diaktifkan")

                        elif cmd == "joinan off" or text.lower() == 'notag off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["joinan"] = False
                                ais.sendMessage(msg.to,"Join dinonaktifkan")

                        elif cmd == "contact on" or text.lower() == 'contact on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["contact"] = True
                                ais.sendMessage(msg.to,"Deteksi contact diaktifkan")

                        elif cmd == "contact off" or text.lower() == 'contact off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["contact"] = False
                                ais.sendMessage(msg.to,"Deteksi contact dinonaktifkan")

                        elif cmd == "respon on" or text.lower() == 'respon on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["detectMention"] = True
                                ais.sendMessage(msg.to,"✯͜͡❂➣ Auto respon diaktifkan")

                        elif cmd == "respon off" or text.lower() == 'respon off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["detectMention"] = False
                                ais.sendMessage(msg.to,"✯͜͡❂➣ Auto respon dinonaktifkan")
                                
                        elif cmd == "respongift on" or text.lower() == 'respongift on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["Mentiongift"] = True
                                ais.sendMessage(msg.to,"✯͜͡❂➣ Auto respon gift diaktifkan")

                        elif cmd == "respongift off" or text.lower() == 'respongift off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["Mentiongift"] = False
                                ais.sendMessage(msg.to,"✯͜͡❂➣ Auto respon gift dinonaktifkan")                                

                        elif cmd == "autojoin on" or text.lower() == 'autojoin on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoJoin"] = True
                                ais.sendMessage(msg.to,"✯͜͡❂➣ Autojoin diaktifkan")

                        elif cmd == "autojoin off" or text.lower() == 'autojoin off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoJoin"] = False
                                ais.sendMessage(msg.to,"✯͜͡❂➣ Autojoin dinonaktifkan")

                        elif cmd == "autoleave on" or text.lower() == 'autoleave on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoLeave"] = True
                                ais.sendMessage(msg.to,"✯͜͡❂➣ Auto Leave Diaktifkan")

                        elif cmd == "autoleave off" or text.lower() == 'autoleave off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoLeave"] = False
                                ais.sendMessage(msg.to,"✯͜͡❂➣ Auto Leave Dimatikan")

                        elif cmd == "autoadd on" or text.lower() == 'autoadd on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoAdd"] = True
                                ais.sendMessage(msg.to,"✯͜͡❂➣ Auto Add Diaktifkan")

                        elif cmd == "autoadd off" or text.lower() == 'autoadd off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoAdd"] = False
                                ais.sendMessage(msg.to,"✯͜͡❂➣ Auto Add Dimatikan")

                        elif cmd == "sticker on" or text.lower() == 'sticker on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["sticker"] = True
                                ais.sendMessage(msg.to,"✯͜͡❂➣ Detect Sticker Diaktifkan")

                        elif cmd == "sticker off" or text.lower() == 'sticker off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["sticker"] = False
                                ais.sendMessage(msg.to,"✯͜͡❂➣ Detect Sticker Dimatikan")

                        elif cmd == "jointicket on" or text.lower() == 'jointicket on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                settings["autoJoinTicket"] = True
                                ais.sendMessage(msg.to,"✯͜͡❂➣ Auto Join Ticket Diaktifkan")

                        elif cmd == "jointicket off" or text.lower() == 'jointicket off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                settings["autoJoinTicket"] = False
                                ais.sendMessage(msg.to,"✯͜͡❂➣ Auto Join Ticket Dimatikan")

#===========COMMAND BLACKLIST============#
                        elif ("Talkban " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           wait["Talkblacklist"][target] = True
                                           ais.sendMessage(msg.to,"Berhasil menambahkan blacklist")
                                       except:
                                           pass

                        elif ("Untalkban " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           del wait["Talkblacklist"][target]
                                           ais.sendMessage(msg.to,"Berhasil menghapus blacklist")
                                       except:
                                           pass

                        elif cmd == "talkban:on" or text.lower() == 'talkban:on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["Talkwblacklist"] = True
                                ais.sendMessage(msg.to,"Kirim kontaknya...")

                        elif cmd == "untalkban:on" or text.lower() == 'untalkban:on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["Talkdblacklist"] = True
                                ais.sendMessage(msg.to,"Kirim kontaknya...")

                        elif ("Ban " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           wait["blacklist"][target] = True
                                           ais.sendMessage(msg.to,"Berhasil menambahkan blacklist")
                                       except:
                                           pass

                        elif ("Unban " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           del wait["blacklist"][target]
                                           ais.sendMessage(msg.to,"Berhasil menghapus blacklist")
                                       except:
                                           pass

                        elif cmd == "ban:on" or text.lower() == 'ban:on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["wblacklist"] = True
                                ais.sendMessage(msg.to,"Kirim kontaknya...")

                        elif cmd == "unban:on" or text.lower() == 'unban:on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["dblacklist"] = True
                                ais.sendMessage(msg.to,"Kirim kontaknya...")

                        elif cmd == "banlist" or text.lower() == 'banlist':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              if wait["blacklist"] == {}:
                                ais.sendMessage(msg.to,"Tidak ada blacklist")
                              else:
                                ma = ""
                                a = 0
                                for m_id in wait["blacklist"]:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +ais.getContact(m_id).displayName + "\n"
                                ais.sendMessage(msg.to,"✯͜͡❂➣  Blacklist User\n\n"+ma+"\nTotal「%s」Blacklist User" %(str(len(wait["blacklist"]))))

                        elif cmd == "talkbanlist" or text.lower() == 'talkbanlist':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              if wait["Talkblacklist"] == {}:
                                ais.sendMessage(msg.to,"Tidak ada Talkban user")
                              else:
                                ma = ""
                                a = 0
                                for m_id in wait["Talkblacklist"]:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +ais.getContact(m_id).displayName + "\n"
                                ais.sendMessage(msg.to,"✯͜͡❂➣  Talkban User\n\n"+ma+"\nTotal「%s」Talkban User" %(str(len(wait["Talkblacklist"]))))

                        elif cmd == "blc" or text.lower() == 'blc':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              if wait["blacklist"] == {}:
                                    ais.sendMessage(msg.to,"Tidak ada blacklist")
                              else:
                                    ma = ""
                                    for i in wait["blacklist"]:
                                        ma = ais.getContact(i)
                                        ais.sendMessage(msg.to, None, contentMetadata={'mid': i}, contentType=13)

                        elif cmd == "clearban" or text.lower() == 'clearban':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              wait["blacklist"] = {}
                              ragets = ais.getContacts(wait["blacklist"])
                              mc = "���%i」User Blacklist" % len(ragets)
                              ais.sendMessage(msg.to,"✯͜͡❂➣ Sukses membersihkan " +mc)
#===========COMMAND SET============#
                        elif 'Set pesan: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set pesan: ','')
                              if spl in [""," ","\n",None]:
                                  ais.sendMessage(msg.to, "Gagal mengganti Pesan Message")
                              else:
                                  wait["message"] = spl
                                  ais.sendMessage(msg.to, "「Pesan Msg」\nPesan Message diganti jadi :\n\n「{}」".format(str(spl)))

                        elif 'Set welcome: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set welcome: ','')
                              if spl in [""," ","\n",None]:
                                  ais.sendMessage(msg.to, "Gagal mengganti Welcome Message")
                              else:
                                  wait["welcome"] = spl
                                  ais.sendMessage(msg.to, "「Welcome Msg」\nWelcome Message diganti jadi :\n\n「{}」".format(str(spl)))
                                  
                        elif 'Set leave: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set leave: ','')
                              if spl in [""," ","\n",None]:
                                  ais.sendMessage(msg.to, "Gagal mengganti Leave Message")
                              else:
                                  wait["leave"] = spl
                                  ais.sendMessage(msg.to, "「Leave Msg」\nLeave Message diganti jadi :\n\n「{}」".format(str(spl)))                                    

                        elif 'Set respon: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set respon: ','')
                              if spl in [""," ","\n",None]:
                                  ais.sendMessage(msg.to, "Gagal mengganti Respon Message")
                              else:
                                  wait["Respontag"] = spl
                                  ais.sendMessage(msg.to, "「Respon Msg」\nRespon Message diganti jadi :\n\n「{}」".format(str(spl)))

                        elif 'Set spam: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set spam: ','')
                              if spl in [""," ","\n",None]:
                                  ais.sendMessage(msg.to, "Gagal mengganti Spam")
                              else:
                                  Setmain["SCmessage1"] = spl
                                  ais.sendMessage(msg.to, "「Spam Msg」\nSpam Message diganti jadi :\n\n「{}」".format(str(spl)))

                        elif 'Set sider: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set sider: ','')
                              if spl in [""," ","\n",None]:
                                  ais.sendMessage(msg.to, "Gagal mengganti Sider Message")
                              else:
                                  wait["mention"] = spl
                                  ais.sendMessage(msg.to, "「Sider Msg」\nSider Message diganti jadi :\n\n「{}」".format(str(spl)))

                        elif text.lower() == "cek pesan":
                            if msg._from in admin:
                               ais.sendMessage(msg.to, "「Pesan Msg」\nPesan Message lu :\n\n「 " + str(wait["message"]) + " 」")

                        elif text.lower() == "cek welcome":
                            if msg._from in admin:
                               ais.sendMessage(msg.to, "「Welcome Msg」\nWelcome Message lu :\n\n「 " + str(wait["welcome"]) + " 」")
                               
                        elif text.lower() == "cek leave":
                            if msg._from in admin:
                               ais.sendMessage(msg.to, "「Leave Msg」\nLeave Message lu :\n\n「 " + str(wait["leave"]) + " 」")                                 

                        elif text.lower() == "cek respon":
                            if msg._from in admin:
                               ais.sendMessage(msg.to, "「Respon Msg」\nRespon Message lu :\n\n「 " + str(wait["Respontag"]) + " 」")

                        elif text.lower() == "cek spam":
                            if msg._from in admin:
                               ais.sendMessage(msg.to, "「Spam Msg」\nSpam Message lu :\n\n「 " + str(Setmain["SCmessage1"]) + " 」")

                        elif text.lower() == "cek sider":
                            if msg._from in admin:
                               ais.sendMessage(msg.to, "「Sider Msg」\nSider Message lu :\n\n「 " + str(wait["mention"]) + " 」")

                        elif cmd == "limit":
                            if msg._from in admin:
                                tz = pytz.timezone("Asia/Jakarta")
                                timeNow = datetime.now(tz=tz)
                                md = "╭━━━━━━━━━━━━─°❂➤\n├━━─°❂➤Allbots\n"
                                try:a1.inviteIntoGroup(msg.to, ["u0301c4c39ba408af941af3f483d66476"]);has = "OK"
                                except:has = "NOT"
                                if has == "OK":sil = "Good"
                                else:sil = "limit"
                                md+=("│❂➤Status bot1: {}\n".format(sil))
                                try:a2.inviteIntoGroup(msg.to, ["u0301c4c39ba408af941af3f483d66476"]);has = "OK"
                                except:has = "NOT"
                                if has == "OK":sil = "Good"
                                else:sil = "limit"
                                md+=("│❂➤Status bot2: {}\n".format(sil))
                                try:a3.inviteIntoGroup(msg.to, ["u0301c4c39ba408af941af3f483d66476"]);has = "OK"
                                except:has = "NOT"
                                if has == "OK":sil = "Good"
                                else:sil = "limit"
                                md+=("│❂➤Status bot3: {}\n".format(sil))
                                try:a4.inviteIntoGroup(msg.to, ["u0301c4c39ba408af941af3f483d66476"]);has = "OK"
                                except:has = "NOT"
                                if has == "OK":sil = "Good"
                                else:sil = "limit"
                                md+=("│❂➤Status bot4: {}\n".format(sil))
                                try:a5.inviteIntoGroup(msg.to, ["u0301c4c39ba408af941af3f483d66476"]);has = "OK"
                                except:has = "NOT"
                                if has == "OK":sil = "Good"
                                else:sil = "limit"
                                md+=("│❂➤Status bot5: {}\n".format(sil))
                                try:a5.inviteIntoGroup(msg.to, ["u0301c4c39ba408af941af3f483d66476"]);has = "OK"
                                except:has = "NOT"
                                if has == "OK":sil = "Good"
                                else:sil = "limit"
                                md+=("│❂➤Status bot6: {}\n".format(sil))
                                ais.sendMessage(msg.to, md+"├━━━━━━━━━━━━━━━━━╮\n├°❂➤Tanggal : "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\n├°❂➤ Jam [ "+ datetime.strftime(timeNow,'%H:%M:%S')+" ]""\n╰━━━━━━━━━━━━━━━━━╯\n".format(sil))

#===========JOIN TICKET============#
                        elif "/ti/g/" in msg.text.lower():
                          if wait["selfbot"] == True:
                              if settings["autoJoinTicket"] == True:
                                 link_re = re.compile('(?:line\:\/|line\.me\/R)\/ti\/g\/([a-zA-Z0-9_-]+)?')
                                 links = link_re.findall(text)
                                 n_links = []
                                 for l in links:
                                     if l not in n_links:
                                        n_links.append(l)
                                 for ticket_id in n_links:
                                     group = ais.findGroupByTicket(ticket_id)
                                     ais.acceptGroupInvitationByTicket(group.id,ticket_id)
                                     ais.sendMessage(msg.to, "sukses masuk group: %s" % str(group.name))

    except Exception as error:
        print (error)

while True:
    try:
        ops = oepoll.singleTrace(count=50)
        if ops is not None:
            for op in ops:
                bot(op)
                # Don't remove this line, if you wan't get error soon!
                oepoll.setRevision(op.revision)
    except Exception as e:
        logError(e)
